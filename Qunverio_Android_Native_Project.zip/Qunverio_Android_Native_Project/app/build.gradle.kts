plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.qunverio.cloud"
 compileSdk = 35
 defaultConfig { applicationId = "com.qunverio.cloud"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
}
dependencies {
 implementation("org.nanohttpd:nanohttpd:2.3.1")
 implementation("androidx.documentfile:documentfile:1.0.1")
 implementation("androidx.core:core-ktx:1.15.0")
}
