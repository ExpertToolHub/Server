package com.qunverio.cloud
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.NetworkInterface

class MainActivity:Activity(){
 private val prefs by lazy{getSharedPreferences("qcloud",MODE_PRIVATE)}
 private lateinit var status:TextView; private lateinit var folder:TextView; private lateinit var urls:TextView
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),1)
  val box=LinearLayout(this).apply{orientation=1;setPadding(24,28,24,24);setBackgroundColor(0xFF101522.toInt())}
  fun label(s:String,n:Float=16f)=TextView(this).apply{text=s;textSize=n;setTextColor(0xFFF2F5FF.toInt());setPadding(0,12,0,12)}
  box.addView(label("QUNVERIO PERSONAL CLOUD",23f));box.addView(label("Native Android server • No Termux"))
  status=label("Status: Stopped");box.addView(status);box.addView(label("Shared folder"));folder=label("Not selected");box.addView(folder)
  box.addView(Button(this).apply{text="Choose cloud folder";setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),10)}})
  box.addView(Button(this).apply{text="START SERVER";setOnClickListener{if(prefs.getString("folder",null)==null)Toast.makeText(this@MainActivity,"Choose a folder first",Toast.LENGTH_LONG).show() else {ContextCompat.startForegroundService(this@MainActivity,Intent(this@MainActivity,CloudServerService::class.java));status.text="Starting…"}}})
  box.addView(Button(this).apply{text="STOP SERVER";setOnClickListener{startService(Intent(this@MainActivity,CloudServerService::class.java).setAction("STOP"));status.text="Stopped"}})
  box.addView(label("Open this URL on another device using the same Wi-Fi / hotspot:"));urls=label("Start server to show URL");box.addView(urls)
  box.addView(label("Remote access: install Tailscale on both devices and use the server phone's Tailscale IP with port 8787. Do not expose this HTTP port publicly."))
  box.addView(Button(this).apply{text="Refresh";setOnClickListener{refresh()}})
  setContentView(ScrollView(this).apply{addView(box)});refresh()
 }
 @Deprecated("Compatibility")
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK){val u=d?.data?:return;val f=d.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION);contentResolver.takePersistableUriPermission(u,f);prefs.edit().putString("folder",u.toString()).apply();refresh()}}
 private fun refresh(){folder.text=prefs.getString("folder",null)?.let{Uri.parse(it).lastPathSegment}?: "Not selected";status.text=if(CloudServerService.running)"RUNNING • Port 8787" else "Stopped";val t=prefs.getString("token","")?:"";urls.text=if(CloudServerService.running)ips().joinToString("\n"){"http://$it:8787/?token=$t"}else "Start server to show URL"}
 private fun ips():List<String>{val out=mutableListOf<String>();try{val es=NetworkInterface.getNetworkInterfaces();while(es.hasMoreElements()){val n=es.nextElement();if(!n.isUp||n.isLoopback)continue;val asx=n.inetAddresses;while(asx.hasMoreElements()){val a=asx.nextElement();val h=a.hostAddress?:continue;if(!a.isLoopbackAddress&&!h.contains(":"))out.add(h)}}}catch(_:Exception){};return out.distinct()}
 override fun onResume(){super.onResume();refresh()}
}
