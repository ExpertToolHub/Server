package com.qunverio.cloud
import android.app.*
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import fi.iki.elonen.NanoHTTPD
import java.net.URLConnection
import java.util.UUID

class CloudServerService:Service(){
 private var server:CloudHttp?=null
 private val prefs by lazy{getSharedPreferences("qcloud",MODE_PRIVATE)}
 override fun onCreate(){super.onCreate();if(android.os.Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("qcloud","Qunverio Cloud",NotificationManager.IMPORTANCE_LOW))}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action=="STOP"){server?.stop();server=null;running=false;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY}
  val folder=prefs.getString("folder",null)?:run{stopSelf();return START_NOT_STICKY}
  var token=prefs.getString("token",null);if(token.isNullOrBlank()){token=UUID.randomUUID().toString().replace("-","").take(24);prefs.edit().putString("token",token).apply()}
  startForeground(8787,NotificationCompat.Builder(this,"qcloud").setContentTitle("Qunverio Cloud running").setContentText("Port 8787").setSmallIcon(android.R.drawable.stat_sys_upload_done).setOngoing(true).build())
  try{server?.stop();server=CloudHttp(folder,token!!).also{it.start(NanoHTTPD.SOCKET_READ_TIMEOUT,false)};running=true}catch(_:Exception){running=false;stopSelf()}
  return START_STICKY
 }
 override fun onDestroy(){server?.stop();running=false;super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
 companion object{@Volatile var running=false}
}
private class CloudHttp(private val tree:String,private val token:String):NanoHTTPD("0.0.0.0",8787){
 private fun root()=DocumentFile.fromTreeUri(App.instance,Uri.parse(tree))
 private fun find(p:String):DocumentFile?{var x=root()?:return null;if(p.isBlank())return x;for(n in p.split('/')){if(n.isBlank()||n=="."||n=="..")return null;x=x.findFile(n)?:return null};return x}
 override fun serve(s:IHTTPSession):Response{
  val auth=s.parameters["token"]?.firstOrNull()?:s.headers["x-qunverio-token"];if(auth!=token)return txt("Unauthorized",Response.Status.UNAUTHORIZED)
  return try{when(s.uri){
   "/",""->home()
   "/api/list"->{val d=find(s.parameters["path"]?.firstOrNull().orEmpty())?:return txt("Not found",Response.Status.NOT_FOUND);val a=org.json.JSONArray();d.listFiles().forEach{a.put(org.json.JSONObject().put("name",it.name).put("dir",it.isDirectory).put("size",it.length()))};newFixedLengthResponse(Response.Status.OK,"application/json",org.json.JSONObject().put("items",a).toString())}
   "/api/file"->sendFile(s)
   "/api/upload"->upload(s)
   "/api/mkdir"->{val d=find(s.parameters["path"]?.firstOrNull().orEmpty())?:return txt("Folder missing",Response.Status.NOT_FOUND);val n=s.parameters["name"]?.firstOrNull().orEmpty();if(!safe(n))return txt("Bad name",Response.Status.BAD_REQUEST);newFixedLengthResponse(if(d.createDirectory(n)!=null)"Created" else "Failed")}
   "/api/delete"->{val f=find(s.parameters["path"]?.firstOrNull().orEmpty())?:return txt("Missing",Response.Status.NOT_FOUND);if(f.uri==root()?.uri)return txt("Forbidden",Response.Status.FORBIDDEN);newFixedLengthResponse(if(f.delete())"Deleted" else "Failed")}
   else->txt("Not found",Response.Status.NOT_FOUND)
  }}catch(e:Exception){txt(e.message?:"Server error",Response.Status.INTERNAL_ERROR)}
 }
 private fun sendFile(s:IHTTPSession):Response{
  val f=find(s.parameters["path"]?.firstOrNull().orEmpty())?:return txt("Not found",Response.Status.NOT_FOUND);if(f.isDirectory)return txt("Folder",Response.Status.BAD_REQUEST)
  val size=f.length();val range=s.headers["range"];val start=range?.substringAfter("bytes=")?.substringBefore("-")?.toLongOrNull()?.coerceIn(0,size)?:0L;val end=if(range!=null)range.substringAfter("-").toLongOrNull()?.coerceIn(start,size-1)?:size-1 else size-1;val count=(end-start+1).coerceAtLeast(0)
  val input=App.instance.contentResolver.openInputStream(f.uri)?:return txt("Cannot open",Response.Status.INTERNAL_ERROR);var skip=start;while(skip>0){val n=input.skip(skip);if(n<=0)break;skip-=n}
  val limited=object:java.io.InputStream(){var left=count;override fun read():Int{if(left<=0)return -1;val b=input.read();if(b>=0)left--;return b};override fun read(b:ByteArray,o:Int,l:Int):Int{if(left<=0)return -1;val n=input.read(b,o,minOf(l.toLong(),left).toInt());if(n>0)left-=n;return n};override fun close(){input.close()}}
  val mime=f.type?:URLConnection.guessContentTypeFromName(f.name?:"")?:"application/octet-stream";val r=newChunkedResponse(if(range==null)Response.Status.OK else Response.Status.PARTIAL_CONTENT,mime,limited);r.addHeader("Accept-Ranges","bytes");r.addHeader("Content-Length",count.toString());if(range!=null)r.addHeader("Content-Range","bytes $start-$end/$size");r.addHeader("Content-Disposition","inline");return r
 }
 private fun upload(s:IHTTPSession):Response{val n=s.parameters["name"]?.firstOrNull().orEmpty();if(!safe(n))return txt("Bad filename",Response.Status.BAD_REQUEST);val d=find(s.parameters["path"]?.firstOrNull().orEmpty())?:return txt("Folder missing",Response.Status.NOT_FOUND);val tmp=java.io.File(App.instance.cacheDir,"q_${UUID.randomUUID()}");s.parseBody(HashMap());tmp.outputStream().use{it.write(s.inputStream.readBytes())};val dest=d.createFile(URLConnection.guessContentTypeFromName(n)?:"application/octet-stream",n)?:return txt("Create failed",Response.Status.INTERNAL_ERROR);App.instance.contentResolver.openOutputStream(dest.uri,"w")!!.use{o->tmp.inputStream().use{it.copyTo(o)}};tmp.delete();return txt("Uploaded")}
 private fun home():Response{val h="<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{background:#101522;color:#eef;font:16px system-ui;padding:16px}button,input{padding:10px;margin:4px;background:#263752;color:white;border:1px solid #567;border-radius:8px}.row{padding:12px;border-bottom:1px solid #345}video{width:100%}</style></head><body><h2>QUNVERIO CLOUD</h2><input type='file' id='f' multiple><button onclick='up()'>Upload</button><input id='folder' placeholder='Folder name'><button onclick='mk()'>New folder</button><div id='list'>Loading</div><video id='v' controls></video><script>let t=new URLSearchParams(location.search).get('token'),p='';async function api(u,o){let r=await fetch(u+(u.includes('?')?'&':'?')+'token='+t,o);if(!r.ok)throw Error(await r.text());return r}async function load(){let j=await(await api('/api/list?path='+encodeURIComponent(p))).json(),h='';for(let x of j.items){let q=p?p+'/'+x.name:x.name;h+='<div class=row>'+(x.dir?'📁 ':'📄 ')+x.name+' <button onclick=\"go('+JSON.stringify(q)+')\">'+(x.dir?'Open':'Play')+'</button><a style=color:lightblue href=\"/api/file?token='+t+'&path='+encodeURIComponent(q)+'\">Download</a></div>'}document.getElementById('list').innerHTML=(p?'<button onclick=back()>Back</button>':'')+h}function go(q){if(q.includes('.')&& !q.endsWith('/')){document.getElementById('v').src='/api/file?token='+t+'&path='+encodeURIComponent(q)}else{p=q;load()}}function back(){p=p.split('/').slice(0,-1).join('/');load()}async function up(){for(let f of document.getElementById('f').files)await fetch('/api/upload?token='+t+'&path='+encodeURIComponent(p)+'&name='+encodeURIComponent(f.name),{method:'POST',body:f});load()}async function mk(){await api('/api/mkdir?path='+encodeURIComponent(p)+'&name='+encodeURIComponent(document.getElementById('folder').value));load()}load().catch(e=>document.getElementById('list').textContent=e.message)</script></body></html>";return newFixedLengthResponse(Response.Status.OK,"text/html; charset=utf-8",h)}
 private fun safe(n:String)=n.isNotBlank()&&n!="."&&n!=".."&&!n.contains("/")&&!n.contains("\\")
 private fun txt(s:String,status:Response.IStatus=Response.Status.OK)=newFixedLengthResponse(status,MIME_PLAINTEXT,s)
}
