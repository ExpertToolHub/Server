# Qunverio Personal Cloud — Android Native Starter

No Termux and no Node.js on the phone. This is Android Studio Kotlin source code, not a precompiled APK.

## Build APK
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync; install Android SDK Platform 35 if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the debug APK on your Android phone.

## Run
1. Open app, choose a shared folder, then tap START SERVER.
2. Keep its foreground notification active.
3. Connect another device to the same Wi-Fi/hotspot.
4. Open the address shown in the app. The URL contains the access token.

## Remote
Install Tailscale on the Android server phone and client device, sign into the same private network, then open the server phone's Tailscale IP on port 8787. Do not port-forward this HTTP server to the public internet.

## MVP limits
Early source starter: file listing, upload, download, folder creation and video endpoint are included. It is not yet production hardened. Rename UI, TLS, robust resumable uploads, pairing, advanced permissions and backup scheduling are future work. Android battery restrictions may stop background work; allow unrestricted battery use if available. This ZIP is source code, not an APK.
