# Qunverio Cloud: Setup Guide (sirf Android phone se)

## Part 1: GitHub par APK banwana (ek baar, ~20 minute)
1. Phone ke browser me github.com par free account banao.
2. **New repository** banao. Naam: `qunverio-cloud`. **Private** rakho. "Add a README" tick karo.
3. Repo me **Add file → Upload files** dabao aur `project.zip` select karke **Commit changes** karo.
   (Zip ko extract mat karo, zip waise hi upload hoga.)
4. **Add file → Create new file** dabao. Naam ki jagah ye likho: `.github/workflows/build.yml`
   (slash likhte hi folders ban jaate hain). `build.yml` file ka poora text paste karo, phir **Commit**.
5. Upar **Actions** tab kholo. "Build Qunverio Cloud APK" chalna shuru ho jayega (8-15 minute).
   Na chale to us workflow par jao aur **Run workflow** dabao.
6. Green tick aane par repo ke **Releases** (right side ya neeche) me jao, `Qunverio-Cloud.apk` download karo.
   Red cross aaye to us run ka error log copy karke mujhe bhejo.

## Part 2: Install
1. Download ki hui APK kholo. "Install unknown apps" allow karo aur Install dabao.
2. Play Protect warning aaye to "Install anyway" (app apni signing key se bani hai).

## Part 3: Server chalana
1. App kholo. **Password set karo** (6+ character).
2. **Start Server** dabao. Notification permission allow karo.
3. **Battery optimization band karo** dabao aur allow karo (zaroori, warna Android server kill kar dega).
4. Poora phone storage chahiye to **Storage** wala button dabao aur "All files access" allow karo.
   Warna files app ke folder me rahengi.
5. App me Wi-Fi/Hotspot ka address dikhega, jaise `http://192.168.1.5:8080`.

## Part 4: Doosra device connect karna
1. Dono device same Wi-Fi par hon, ya doosra device is phone ke hotspot se juda ho.
2. Doosre device ke browser me wo address kholo.
3. Password se login karo, ya app me **Naya code banao** dabao aur dashboard me **Code se pair** me 6 digit code daalo.
4. Dashboard se files upload/download/move karo aur video/gaane seedha chalao.

## Part 5: Internet se access (Tailscale, free)
1. Phone aur doosre device dono par Tailscale app install karo (tailscale.com), same account se login karo.
2. Phone ke app me address list me `Tailscale (remote)` ka `http://100.x.x.x:8080` dikhega.
3. Doosre device par Tailscale ON rakhke wahi address kholo. Traffic encrypted hota hai, aur login ab bhi lagta hai.
4. Dashboard → Settings me ye address "Remote URL" me save kar do.

Port forwarding mat karo. Mobile data me kaam nahi karta aur phone ko public karta hai.

## Dhyan rakhne ki baatein
- Phone charging par rakho, garam ho sakta hai.
- Phone band ya battery khatam hui to cloud band.
- Important files ka backup alag rakho.
- Android Studio/PC ke bina compile nahi kar paye, isliye pehli build me error aa sakta hai. Log bhejo, main fix kar dunga.
- Repo **Private** hi rakho. Signing key password code me hai (sirf personal use ke liye).
