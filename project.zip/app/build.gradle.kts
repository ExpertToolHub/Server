plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.qunverio.cloud"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.qunverio.turbo"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.1.0"
    }

    signingConfigs {
        create("qc") {
            storeFile = file("qunverio.jks")
            storePassword = "qunverio123"
            keyAlias = "qunverio"
            keyPassword = "qunverio123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("qc")
        }
        debug {
            signingConfig = signingConfigs.getByName("qc")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/INDEX.LIST",
                "META-INF/DEPENDENCIES",
                "META-INF/io.netty.versions.properties",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "/META-INF/{AL2.0,LGPL2.1}"
            )
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("io.ktor:ktor-server-core:2.3.12")
    implementation("io.ktor:ktor-server-cio:2.3.12")
    implementation("io.ktor:ktor-server-status-pages:2.3.12")
    implementation("org.slf4j:slf4j-nop:2.0.13")
}
