(function () {
'use strict';

/* ---------- helpers ---------- */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
};
function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtSize(n) {
  if (!n || n < 0) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i === 0 ? n : n.toFixed(n >= 100 ? 0 : 1)) + ' ' + u[i];
}
const fmtSpeed = n => fmtSize(n) + '/s';
function fmtDur(ms) {
  let s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400); s %= 86400;
  const h = Math.floor(s / 3600); s %= 3600;
  const m = Math.floor(s / 60);
  return (d ? d + 'd ' : '') + (h || d ? h + 'h ' : '') + m + 'm';
}
function ago(t) {
  const s = Math.floor((Date.now() - t) / 1000);
  if (s < 5) return T('now');
  if (s < 60) return s + 's';
  if (s < 3600) return Math.floor(s / 60) + 'm';
  if (s < 86400) return Math.floor(s / 3600) + 'h';
  return Math.floor(s / 86400) + 'd';
}
function fmtDate(t) {
  const d = new Date(t);
  return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 3200);
}

/* ---------- language ---------- */
const L = {
  hi: {
    login_sub: 'Apne phone ke cloud me login karo', tab_pw: 'Password', tab_code: 'Code se pair',
    ph_devname: 'Is device ka naam', ph_pw: 'Password', ph_code: '6 digit code (phone ke app me)', login_btn: 'Login',
    nav_dash: 'Dashboard', nav_files: 'Files', nav_devices: 'Devices', nav_settings: 'Settings', logout: 'Logout',
    srv_on: 'Server ON', addr: 'Server ke address', storage: 'Storage', speed: 'Speed', devices_c: 'Connected devices',
    uptime: 'Chalne ka time', transfers: 'Chalu transfers', none: 'Abhi kuch nahi', activity: 'Recent activity',
    search: 'Search...', new_folder: '＋ Folder', upload: '⬆ Upload', drop: 'Files yahan chhodo',
    revoke_all: 'Baaki sab logout karo',
    dev_help: "Naya device jodne ke liye phone ke app me 'Naya code banao' dabao, phir doosre device par 'Code se pair' use karo.",
    appearance: 'Look & Language', server: 'Server', srv_name: 'Server ka naam', remote_url: 'Remote URL (Tailscale / tunnel)',
    save: 'Save', chg_pw: 'Password badlo', old_pw: 'Purana password', new_pw: 'Naya password (6+)',
    pw_note: 'Password badalne par baaki sab devices logout ho jaayenge.', about: 'Jaankari',
    now: 'abhi', used: 'use hua', free: 'khaali', of: 'me se', cloud_used: 'Cloud files', empty: 'Ye folder khaali hai',
    no_results: 'Kuch nahi mila', theme_dark: '🌙 Dark theme', theme_light: '☀ Light theme', lang_btn: '🌐 Language: Hinglish',
    saved: 'Save ho gaya', cancel: 'Cancel', ok: 'OK', create: 'Banao', rename: 'Naam badlo', del: 'Delete',
    move_to: 'Kahan move karna hai?', here: 'Yahan move karo', folder_name: 'Folder ka naam', new_name: 'Naya naam',
    confirm_del: 'Pakka delete karna hai?', download: 'Download', online: 'Online', last_seen: 'Last connected',
    can_write: 'Upload/Delete allowed', admin: 'Admin', paired: 'Paired device', you: 'Ye device', remove: 'Hatao',
    confirm_rm: 'Is device ko hatana hai?', uploading: 'Upload ho raha hai', done: 'Ho gaya', retry: 'Dobara try...',
    failed: 'Fail', close: 'Band karo', remote_none: 'Remote URL set nahi hai (Settings me daalo)', remote: 'Remote',
    cpu_ram: 'App RAM', devices_online: 'online', total_in: 'Total upload', total_out: 'Total download', root: 'Folder',
    app_mode: 'App folder', pub_mode: 'Poora phone storage', mode: 'Storage mode', ver: 'Version'
  },
  en: {
    login_sub: "Sign in to your phone's cloud", tab_pw: 'Password', tab_code: 'Pair with code',
    ph_devname: 'Name of this device', ph_pw: 'Password', ph_code: '6-digit code (shown in phone app)', login_btn: 'Sign in',
    nav_dash: 'Dashboard', nav_files: 'Files', nav_devices: 'Devices', nav_settings: 'Settings', logout: 'Logout',
    srv_on: 'Server ON', addr: 'Server addresses', storage: 'Storage', speed: 'Speed', devices_c: 'Connected devices',
    uptime: 'Uptime', transfers: 'Active transfers', none: 'Nothing right now', activity: 'Recent activity',
    search: 'Search...', new_folder: '＋ Folder', upload: '⬆ Upload', drop: 'Drop files here',
    revoke_all: 'Sign out all others',
    dev_help: "To add a device, tap 'New code' in the phone app, then use 'Pair with code' on the other device.",
    appearance: 'Look & Language', server: 'Server', srv_name: 'Server name', remote_url: 'Remote URL (Tailscale / tunnel)',
    save: 'Save', chg_pw: 'Change password', old_pw: 'Old password', new_pw: 'New password (6+)',
    pw_note: 'Changing the password signs out all other devices.', about: 'About',
    now: 'now', used: 'used', free: 'free', of: 'of', cloud_used: 'Cloud files', empty: 'This folder is empty',
    no_results: 'Nothing found', theme_dark: '🌙 Dark theme', theme_light: '☀ Light theme', lang_btn: '🌐 Language: English',
    saved: 'Saved', cancel: 'Cancel', ok: 'OK', create: 'Create', rename: 'Rename', del: 'Delete',
    move_to: 'Move to which folder?', here: 'Move here', folder_name: 'Folder name', new_name: 'New name',
    confirm_del: 'Delete permanently?', download: 'Download', online: 'Online', last_seen: 'Last connected',
    can_write: 'Can upload/delete', admin: 'Admin', paired: 'Paired device', you: 'This device', remove: 'Remove',
    confirm_rm: 'Remove this device?', uploading: 'Uploading', done: 'Done', retry: 'Retrying...',
    failed: 'Failed', close: 'Close', remote_none: 'Remote URL not set (add it in Settings)', remote: 'Remote',
    cpu_ram: 'App RAM', devices_online: 'online', total_in: 'Total uploaded', total_out: 'Total downloaded', root: 'Folder',
    app_mode: 'App folder', pub_mode: 'Full phone storage', mode: 'Storage mode', ver: 'Version'
  }
};
Object.assign(L.hi, {
  shares: 'Share links', share_title: 'Share link', dur1: '1 ghanta', dur24: '1 din', dur168: '7 din',
  link_exp: 'Expire', revoke: 'Band karo', copy: 'Copy', no_shares: 'Koi share link nahi',
  share_hint: 'Ye link jiske paas ho wo bina password ke dekh/download kar sakta hai. Link kitni der chale, chuno. Doosre device ko usi Wi-Fi/hotspot (ya Tailscale) par hona chahiye. VLC me Network Stream me bhi chalega.'
});
Object.assign(L.en, {
  shares: 'Share links', share_title: 'Share link', dur1: '1 hour', dur24: '1 day', dur168: '7 days',
  link_exp: 'Expires', revoke: 'Revoke', copy: 'Copy', no_shares: 'No share links',
  share_hint: 'Anyone with this link can view/download without a password. Pick how long it works. The other device must be on the same Wi-Fi/hotspot (or Tailscale). Works in VLC Network Stream too.'
});
Object.assign(L.hi, {
  speedtest: 'Speed test', speed_hint: 'Is device se phone tak ki asli speed napo. Fast aur Normal dono ki tulna hogi.', speed_run: 'Test chalao',
  speed_fast: 'Fast mode', speed_norm: 'Normal mode', speed_https: 'Speed test sirf http address par chalta hai'
});
Object.assign(L.en, {
  speedtest: 'Speed test', speed_hint: 'Measure the real speed from this device to the phone. Compares Fast and Normal mode.', speed_run: 'Run test',
  speed_fast: 'Fast mode', speed_norm: 'Normal mode', speed_https: 'Speed test works only on an http address'
});
let lang = store.get('qc_lang', 'hi');
function T(k) { return (L[lang] && L[lang][k]) || L.en[k] || k; }
function applyLang() {
  document.documentElement.lang = lang === 'hi' ? 'hi' : 'en';
  $$('[data-i18n]').forEach(e => { e.textContent = T(e.dataset.i18n); });
  $$('[data-i18n-ph]').forEach(e => { e.placeholder = T(e.dataset.i18nPh); });
  $('#lang-btn').textContent = T('lang_btn');
  $('#theme-btn').textContent = document.documentElement.dataset.theme === 'light' ? T('theme_dark') : T('theme_light');
}

/* ---------- theme ---------- */
function setTheme(t) {
  document.documentElement.dataset.theme = t;
  store.set('qc_theme', t);
  const m = document.querySelector('meta[name=theme-color]');
  if (m) m.content = t === 'light' ? '#f3f5fb' : '#0e1320';
  $('#theme-btn').textContent = t === 'light' ? T('theme_dark') : T('theme_light');
}
setTheme(store.get('qc_theme', matchMedia && matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'));

/* ---------- API ---------- */
async function api(path, opts) {
  opts = opts || {};
  const init = { method: opts.method || 'GET', headers: { 'X-QC': '1' }, credentials: 'same-origin' };
  if (opts.body !== undefined) {
    init.method = opts.method || 'POST';
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(opts.body);
  }
  let r;
  try { r = await fetch(path, init); } catch (e) { throw { status: 0, error: 'Network error' }; }
  let j = {};
  try { j = await r.json(); } catch (e) {}
  if (r.status === 401 && path !== '/api/login' && path !== '/api/pair') { showLogin(); }
  if (!r.ok) throw { status: r.status, error: j.error || 'Error', data: j };
  return j;
}
const guard = fn => async (...a) => { try { return await fn(...a); } catch (e) { if (e && e.status !== 401) toast((e && e.error) || 'Error'); } };

/* ---------- state ---------- */
let me = null, cur = '', pollTimer = null, view = 'dash', searchMode = false;

/* ---------- login ---------- */
function defaultName() {
  const ua = navigator.userAgent;
  let os = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iPhone' : /Windows/.test(ua) ? 'Windows' : /Mac/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : 'Device';
  let br = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  return os + ' ' + br;
}
function showLogin(msg) {
  stopPolling();
  me = null;
  $('#app').classList.add('hidden');
  $('#login').classList.remove('hidden');
  $('#login-err').textContent = msg || '';
}
let loginMode = 'pw';
function setLoginMode(m) {
  loginMode = m;
  $('#tab-pw').classList.toggle('on', m === 'pw');
  $('#tab-code').classList.toggle('on', m === 'code');
  $('#tab-guest').classList.toggle('on', m === 'guest');
  $('#pw').placeholder = m === 'guest' ? 'Guest password' : T('ph_pw');
  $('#pw').classList.toggle('hidden', m === 'code');
  $('#code').classList.toggle('hidden', m !== 'code');
  $('#login-err').textContent = '';
}
async function doLogin() {
  const name = $('#dev-name').value.trim() || defaultName();
  store.set('qc_devname', name);
  $('#login-err').textContent = '';
  try {
    if (loginMode === 'pw') await api('/api/login', { body: { password: $('#pw').value, name } });
    else if (loginMode === 'guest') await api('/api/login', { body: { password: $('#pw').value, name, guest: true } });
    else await api('/api/pair', { body: { code: $('#code').value.trim(), name } });
    $('#pw').value = ''; $('#code').value = '';
    await boot();
  } catch (e) { $('#login-err').textContent = (e && e.error) || 'Error'; }
}

/* ---------- boot ---------- */
async function boot() {
  let r;
  try { r = await api('/api/me'); } catch (e) { showLogin(); return; }
  $('#brand-name').textContent = r.name || 'Qunverio Turbo';
  document.title = r.name || 'Qunverio Turbo';
  if (!r.auth) {
    $('#login-title').textContent = r.name || 'Qunverio Turbo';
    if (!r.hasPassword) showLogin('Pehle phone ke app me password set karo');
    else showLogin();
    return;
  }
  me = r.device;
  if (!me.admin && !me.guestActive) { showLogin('Guest access abhi band hai. Admin se allow karwao.'); return; }
  $('#login').classList.add('hidden');
  $('#app').classList.remove('hidden');
  $('#who').textContent = me.name + (me.admin ? ' · ' + T('admin') : ' · ' + T('paired'));
  $$('.adminonly').forEach(e => e.classList.toggle('hidden', !me.admin));
  $('#btn-upload').classList.toggle('hidden', !me.canWrite);
  $('#btn-mkdir').classList.toggle('hidden', !me.canWrite);
  $$('[data-view="devices"]').forEach(e => e.classList.toggle('hidden', !me.admin));
  $$('[data-view="dash"]').forEach(e => e.classList.toggle('hidden', !me.admin));
  $('#about-text').innerHTML = '';
  go(me.admin ? view : (view === 'dash' || view === 'devices' ? 'files' : view));
}

/* ---------- navigation ---------- */
function go(v) {
  if ((v === 'devices' || v === 'dash') && me && !me.admin) v = 'files';
  view = v;
  $$('.view').forEach(e => e.classList.add('hidden'));
  $('#v-' + v).classList.remove('hidden');
  $$('.nav').forEach(b => b.classList.toggle('on', b.dataset.view === v));
  stopPolling();
  if (v === 'dash') { pollStatus(); pollTimer = setInterval(pollStatus, 2000); }
  if (v === 'files') loadDir(cur);
  if (v === 'devices') { loadDevices(); loadShares(); pollTimer = setInterval(loadDevices, 5000); }
  if (v === 'settings') loadSettings();
}
function stopPolling() { if (pollTimer) clearInterval(pollTimer); pollTimer = null; }

/* ---------- dashboard ---------- */
async function pollStatus() {
  let s;
  try { s = await api('/api/status'); } catch (e) { return; }
  const addr = $('#addr-list');
  const kindName = { wifi: 'Wi-Fi', hotspot: 'Hotspot', tailscale: 'Tailscale', vpn: 'VPN', ethernet: 'Ethernet', other: 'Network' };
  addr.innerHTML = s.addresses.map(a =>
    `<div class="addr"><div><span class="k">${esc(kindName[a.kind] || a.kind)}</span>${esc(a.url)}</div><button class="ghost" data-copy="${esc(a.url)}">Copy</button></div>`
  ).join('') || `<div class="muted small">No network</div>`;
  $('#remote-row').innerHTML = s.remoteUrl
    ? `${T('remote')}: <b>${esc(s.remoteUrl)}</b>`
    : T('remote_none');

  const used = s.totalSpace - s.freeSpace;
  const pct = s.totalSpace ? used / s.totalSpace * 100 : 0;
  $('#bar-used').style.width = pct.toFixed(1) + '%';
  $('#storage-text').textContent = `${fmtSize(used)} ${T('used')} · ${fmtSize(s.freeSpace)} ${T('free')} (${fmtSize(s.totalSpace)})`;
  $('#cloud-text').textContent = `${T('cloud_used')}: ${fmtSize(s.usedByCloud)}`;

  $('#sp-in').textContent = fmtSpeed(s.speedIn);
  $('#sp-out').textContent = fmtSpeed(s.speedOut);
  $('#tot-text').textContent = `${T('total_in')}: ${fmtSize(s.bytesIn)} · ${T('total_out')}: ${fmtSize(s.bytesOut)}`;

  $('#cpu').textContent = s.cpu.toFixed(0) + '%';
  $('#bar-cpu').style.width = Math.min(100, s.cpu) + '%';
  const ramUsed = s.ramTotal - s.ramFree;
  const rp = s.ramTotal ? ramUsed / s.ramTotal * 100 : 0;
  $('#ram').textContent = rp.toFixed(0) + '%';
  $('#bar-ram').style.width = rp + '%';
  $('#ram-text').textContent = `${fmtSize(ramUsed)} / ${fmtSize(s.ramTotal)} · ${T('cpu_ram')}: ${fmtSize(s.appRam)}`;

  $('#dev-count').textContent = s.devicesOnline;
  $('#dev-text').textContent = `${s.devicesOnline} ${T('devices_online')} / ${s.devicesTotal}`;
  $('#uptime').textContent = fmtDur(s.uptime);

  $('#tr-list').innerHTML = s.transfers.length ? s.transfers.map(t => {
    const p = t.total ? Math.min(100, t.done / t.total * 100) : 100;
    const ic = t.kind === 'up' ? '⬆' : t.kind === 'stream' ? '▶' : '⬇';
    return `<div class="tr"><div class="row" style="justify-content:space-between"><span>${ic} ${esc(t.name)}</span><span class="small muted">${esc(t.device)} · ${p.toFixed(0)}%</span></div><div class="bar"><div style="width:${p}%"></div></div></div>`;
  }).join('') : `<p class="muted small">${T('none')}</p>`;

  $('#act-list').innerHTML = s.activity.length ? s.activity.slice(0, 15).map(a =>
    `<div class="act"><span><b>${esc(a.device)}</b> · ${esc(a.action)} ${esc(a.detail || '')}</span><span class="t">${ago(a.t)}</span></div>`
  ).join('') : `<p class="muted small">${T('none')}</p>`;

  $('#about-text').innerHTML =
    `${T('mode')}: ${s.storageMode === 'public' ? T('pub_mode') : T('app_mode')}<br>${T('root')}: ${esc(s.root)}`;
}

/* ---------- files ---------- */
const EXT = {
  video: ['mp4', 'mkv', 'webm', 'mov', 'm4v', 'avi', '3gp', 'ogv'],
  audio: ['mp3', 'm4a', 'aac', 'wav', 'flac', 'ogg', 'opus', 'oga'],
  image: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif']
};
function kindOf(name) {
  const e = name.split('.').pop().toLowerCase();
  for (const k in EXT) if (EXT[k].includes(e)) return k;
  if (e === 'pdf') return 'pdf';
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(e)) return 'zip';
  if (['apk'].includes(e)) return 'apk';
  return 'file';
}
const ICON = { dir: '📁', video: '🎬', audio: '🎵', image: '🖼', pdf: '📕', zip: '🗜', apk: '📦', file: '📄' };
const fileUrl = (p, dl) => '/api/file?path=' + encodeURIComponent(p) + (dl ? '&dl=1' : '');
const fastHost = port => location.protocol + '//' + location.hostname + ':' + port;
/* Fast mode: bulk bytes go through the fast socket server using a short-lived ticket. Falls back to the normal path. */
/* Turbo download: 4 connections at once for mid-size files (needs memory = file size, so capped) */
const TURBO_MIN = 16 * 1024 * 1024, TURBO_MAX = 400 * 1024 * 1024;
async function turboDownload(path, name, size) {
  const url = await fileLink(path, name, true);
  if (location.protocol !== 'http:' || size < TURBO_MIN || size > TURBO_MAX || url.indexOf('/f/') < 0) { location.href = url; return; }
  const PART = 8 * 1024 * 1024, N = 4;
  const parts = new Array(Math.ceil(size / PART));
  let next = 0, got = 0, failed = false;
  const t0 = Date.now();
  const el = document.createElement('div');
  el.className = 'up';
  el.innerHTML = `<div class="top"><span>⬇ ${esc(name)}</span><span class="st small muted"></span></div><div class="bar"><div></div></div>`;
  $('#uploads').appendChild(el);
  const bar = $('.bar>div', el), st = $('.st', el);
  async function worker() {
    while (!failed) {
      const i = next++;
      if (i >= parts.length) return;
      const a = i * PART, b = Math.min(size - 1, a + PART - 1);
      let ok = false;
      for (let k = 0; k < 3 && !ok; k++) {
        try {
          const r = await fetch(url, { headers: { Range: 'bytes=' + a + '-' + b } });
          if (r.status !== 206 && r.status !== 200) throw 0;
          const buf = await r.arrayBuffer();
          if (buf.byteLength !== b - a + 1) throw 0;
          parts[i] = buf; got += buf.byteLength; ok = true;
          bar.style.width = (got / size * 100) + '%';
          st.textContent = `${fmtSize(got)} / ${fmtSize(size)} · ${fmtSpeed(got / Math.max(0.5, (Date.now() - t0) / 1000))}`;
        } catch (e) { await sleep(500); }
      }
      if (!ok) { failed = true; return; }
    }
  }
  await Promise.all(Array.from({ length: N }, worker));
  if (failed) { el.remove(); location.href = url; return; }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(parts));
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); el.remove(); }, 4000);
}

async function fileLink(path, name, dl) {
  if (location.protocol === 'http:') {
    try {
      const t = await api('/api/ticket?path=' + encodeURIComponent(path));
      return fastHost(t.port) + '/f/' + t.token + '/' + encodeURIComponent(name) + (dl ? '?dl=1' : '');
    } catch (e) { /* use normal path */ }
  }
  return fileUrl(path, dl);
}

function renderCrumbs() {
  const parts = cur ? cur.split('/') : [];
  let html = `<a data-path="">🏠</a>`;
  let acc = '';
  for (const p of parts) {
    acc += (acc ? '/' : '') + p;
    html += ` / <a data-path="${esc(acc)}">${esc(p)}</a>`;
  }
  $('#crumbs').innerHTML = html;
}
const loadDir = guard(async function (path) {
  searchMode = false;
  $('#search').value = '';
  const r = await api('/api/list?path=' + encodeURIComponent(path || ''));
  cur = r.path;
  renderCrumbs();
  renderFiles(r.items);
});
function renderFiles(items) {
  const box = $('#file-list');
  if (!items.length) { box.innerHTML = `<div class="empty">${searchMode ? T('no_results') : T('empty')}</div>`; return; }
  const canW = me && me.canManage;
  box.innerHTML = items.map(it => {
    const k = it.dir ? 'dir' : kindOf(it.name);
    const sub = it.dir ? fmtDate(it.mtime) : `${fmtSize(it.size)} · ${fmtDate(it.mtime)}`;
    const parent = searchMode && it.path.includes('/') ? ' · ' + esc(it.path.slice(0, it.path.lastIndexOf('/'))) : '';
    return `<div class="f" data-path="${esc(it.path)}" data-dir="${it.dir ? 1 : 0}" data-name="${esc(it.name)}" data-size="${it.size || 0}">
      <div class="ic ${k}" ${k === 'video' ? `data-vthumb="${esc(it.path)}"` : ''}>${k === 'image' && (it.size || 0) <= 4194304 ? `<img class="th" loading="lazy" alt="" src="${esc(fileUrl(it.path, false))}">` : ICON[k]}${k === 'video' ? '<span class="pb">▶</span>' : ''}</div>
      <div class="nm" data-act="open">${esc(it.name)}<small>${sub}${parent}</small></div>
      <div class="acts">
        ${it.dir ? '' : `<button data-act="dl" title="${T('download')}">⬇</button>`}
        ${canW ? `<button data-act="rename" title="${T('rename')}">✏</button><button data-act="move">📂</button><button data-act="del" class="danger" title="${T('del')}">🗑</button>` : ''}
      </div></div>`;
  }).join('');
  box.classList.toggle('grid', store.get('qc_view', 'list') === 'grid');
  thumbObserve();
}
let thumbIO = null;
function thumbObserve() {
  if (!('IntersectionObserver' in window)) return;
  if (thumbIO) thumbIO.disconnect();
  thumbIO = new IntersectionObserver(es => {
    es.forEach(en => {
      if (!en.isIntersecting) return;
      const d = en.target;
      thumbIO.unobserve(d);
      const v = document.createElement('video');
      v.className = 'th';
      v.muted = true;
      v.preload = 'metadata';
      v.setAttribute('playsinline', '');
      v.src = fileUrl(d.dataset.vthumb, false) + '#t=1';
      v.addEventListener('loadeddata', () => { d.insertBefore(v, d.firstChild); d.classList.add('has'); });
    });
  }, { rootMargin: '120px' });
  $$('#file-list [data-vthumb]').forEach(d => thumbIO.observe(d));
}

function modal(html, wide) {
  const m = $('#modal'), b = $('#modal-box');
  b.className = 'modal-box' + (wide ? ' wide' : '');
  b.innerHTML = html;
  m.classList.remove('hidden');
  return b;
}
function closeModal() {
  const b = $('#modal-box');
  $$('video,audio', b).forEach(v => { try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) {} });
  $('#modal').classList.add('hidden');
  b.onclick = null;
  b.innerHTML = '';
}
function ask(title, value, okLabel) {
  return new Promise(res => {
    const b = modal(`<h3>${esc(title)}</h3><input id="ask-in" type="text" maxlength="200" value="${esc(value || '')}">
      <div class="modal-actions"><button class="ghost" id="ask-no">${T('cancel')}</button><button class="primary" id="ask-ok">${esc(okLabel || T('ok'))}</button></div>`);
    const inp = $('#ask-in', b);
    inp.focus(); inp.select();
    const fin = v => { closeModal(); res(v); };
    $('#ask-no', b).onclick = () => fin(null);
    $('#ask-ok', b).onclick = () => fin(inp.value.trim());
    inp.onkeydown = e => { if (e.key === 'Enter') fin(inp.value.trim()); };
  });
}
function confirmBox(msg) {
  return new Promise(res => {
    const b = modal(`<h3>${esc(msg)}</h3><div class="modal-actions"><button class="ghost" id="c-no">${T('cancel')}</button><button class="primary" id="c-ok">${T('ok')}</button></div>`);
    $('#c-no', b).onclick = () => { closeModal(); res(false); };
    $('#c-ok', b).onclick = () => { closeModal(); res(true); };
  });
}
async function pickFolder(title) {
  return new Promise(async res => {
    let at = '';
    const b = modal(`<h3>${esc(title)}</h3><div id="pk-path" class="small muted"></div><div class="pick" id="pk-list"></div>
      <div class="modal-actions"><button class="ghost" id="pk-no">${T('cancel')}</button><button class="primary" id="pk-ok">${T('here')}</button></div>`);
    async function show(p) {
      try {
        const r = await api('/api/list?path=' + encodeURIComponent(p));
        at = r.path;
        $('#pk-path', b).textContent = '/' + at;
        let h = at ? `<div data-p="${esc(at.includes('/') ? at.slice(0, at.lastIndexOf('/')) : '')}">⬆ ..</div>` : '';
        h += r.items.filter(i => i.dir).map(i => `<div data-p="${esc(i.path)}">📁 ${esc(i.name)}</div>`).join('');
        $('#pk-list', b).innerHTML = h;
      } catch (e) { toast((e && e.error) || 'Error'); }
    }
    $('#pk-list', b).onclick = e => { const d = e.target.closest('[data-p]'); if (d) show(d.dataset.p); };
    $('#pk-no', b).onclick = () => { closeModal(); res(null); };
    $('#pk-ok', b).onclick = () => { closeModal(); res(at); };
    show(cur);
  });
}

const fileAction = guard(async function (row, act) {
  const path = row.dataset.path, name = row.dataset.name, isDir = row.dataset.dir === '1';
  if (act === 'open') {
    if (isDir) return loadDir(path);
    const k = kindOf(name);
    if (k === 'video' || k === 'audio' || k === 'image') return preview(path, name, k);
    await turboDownload(path, name, parseInt(row.dataset.size || '0', 10));
  } else if (act === 'dl') {
    await turboDownload(path, name, parseInt(row.dataset.size || '0', 10));
  } else if (act === 'rename') {
    const n = await ask(T('rename'), name, T('ok'));
    if (n && n !== name) { await api('/api/rename', { body: { path, name: n } }); toast(T('saved')); refreshList(); }
  } else if (act === 'move') {
    const to = await pickFolder(T('move_to'));
    if (to !== null) { await api('/api/move', { body: { path, to } }); toast(T('saved')); refreshList(); }
  } else if (act === 'share') {
    await shareDialog(path, name);
  } else if (act === 'del') {
    if (await confirmBox(T('confirm_del') + ' ' + name)) {
      await api('/api/delete', { body: { path } }); refreshList();
    }
  }
});
function refreshList() { if (searchMode) doSearch(); else loadDir(cur); }

/* ================= Media viewer (video / audio / photo) ================= */
const VW_SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];
const VW_FITS = [['contain', 'Fit'], ['cover', 'Fill'], ['fill', 'Stretch']];
let VW = null;

function fmtTime(s) {
  if (!isFinite(s) || s < 0) s = 0;
  s = Math.floor(s);
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : String(m)) + ':' + String(x).padStart(2, '0');
}
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

async function preview(path, name, kind) {
  const list = $$('#file-list .f').filter(r => r.dataset.dir !== '1')
    .map(r => ({ path: r.dataset.path, name: r.dataset.name, kind: kindOf(r.dataset.name) }))
    .filter(x => x.kind === 'video' || x.kind === 'audio' || x.kind === 'image');
  let idx = list.findIndex(x => x.path === path);
  if (idx < 0) { list.push({ path, name, kind }); idx = list.length - 1; }
  openViewer(list, idx);
}

function openViewer(list, idx) {
  closeViewer(true);
  const root = document.createElement('div');
  root.id = 'vw';
  root.className = 'vw';
  root.innerHTML = `
    <div class="vw-stage" id="vw-stage"></div>
    <div class="vw-gest" id="vw-gest"></div>
    <div class="vw-spin hidden" id="vw-spin"></div>
    <div class="vw-flash hidden" id="vw-flash"></div>
    <div class="vw-err hidden" id="vw-err"></div>
    <div class="vw-top vw-ui">
      <button class="vw-b" id="vw-back" aria-label="Back">←</button>
      <div class="vw-title"><b id="vw-name"></b><small id="vw-count"></small></div>
      <a class="vw-b" id="vw-dl" aria-label="Download">⬇</a>
    </div>
    <button class="vw-side l vw-ui" id="vw-sl" aria-label="Previous">‹</button>
    <button class="vw-side r vw-ui" id="vw-sr" aria-label="Next">›</button>
    <div class="vw-center vw-ui">
      <button class="vw-b big" id="vw-prev" aria-label="Previous">⏮</button>
      <button class="vw-b big" id="vw-rw" aria-label="Back 10s">⟲<small>10</small></button>
      <button class="vw-b huge" id="vw-play" aria-label="Play/Pause">▶</button>
      <button class="vw-b big" id="vw-ff" aria-label="Forward 10s">⟳<small>10</small></button>
      <button class="vw-b big" id="vw-next" aria-label="Next">⏭</button>
    </div>
    <div class="vw-bottom vw-ui">
      <div class="vw-seekrow">
        <span id="vw-cur">0:00</span>
        <div class="vw-seek" id="vw-seek"><div class="vw-buf" id="vw-buf"></div><div class="vw-pg" id="vw-pg"></div><div class="vw-knob" id="vw-knob"></div><div class="vw-bubble hidden" id="vw-bubble"></div></div>
        <span id="vw-dur">0:00</span>
      </div>
      <div class="vw-btns">
        <button class="vw-b" id="vw-lock" aria-label="Lock">🔒</button>
        <button class="vw-b txt" id="vw-speed">1×</button>
        <button class="vw-b txt" id="vw-fit">Fit</button>
        <button class="vw-b" id="vw-mute" aria-label="Mute">🔊</button>
        <button class="vw-b" id="vw-pip" aria-label="Picture in picture">⧉</button>
        <button class="vw-b" id="vw-fs" aria-label="Fullscreen">⛶</button>
      </div>
    </div>
    <button class="vw-unlock hidden" id="vw-unlock">🔓 Unlock</button>`;
  document.body.appendChild(root);
  document.body.classList.add('vw-open');
  VW = {
    root, list, idx, seq: 0, el: null, kind: '', locked: false, speed: 1, fit: 0, hideT: null, flashT: null,
    seeking: false, bright: 1, scale: 1, tx: 0, ty: 0, pushed: true, lastTap: 0, tapT: null
  };
  try { history.pushState({ vw: 1 }, ''); } catch (e) { VW.pushed = false; }
  bindViewer();
  loadItem(idx);
}

function closeViewer(silent) {
  if (!VW) return;
  const v = VW;
  VW = null;
  try { if (v.el) { v.el.pause(); v.el.removeAttribute('src'); v.el.load(); } } catch (e) {}
  try { if (document.fullscreenElement) document.exitFullscreen(); } catch (e) {}
  try { if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) {}
  clearTimeout(v.hideT);
  v.root.remove();
  document.body.classList.remove('vw-open');
  document.removeEventListener('keydown', vwKey);
  if (!silent && v.pushed) { try { history.back(); } catch (e) {} }
}
window.addEventListener('popstate', () => { if (VW) { VW.pushed = false; closeViewer(true); } });

const vq = id => VW && $('#' + id, VW.root);

function vwFlash(html, ms) {
  const f = vq('vw-flash');
  if (!f) return;
  f.innerHTML = html;
  f.classList.remove('hidden');
  clearTimeout(VW.flashT);
  VW.flashT = setTimeout(() => f.classList.add('hidden'), ms || 700);
}

function vwShowUI() {
  if (!VW || VW.locked) return;
  VW.root.classList.remove('ui-hide');
  clearTimeout(VW.hideT);
  if (VW.kind === 'video') {
    VW.hideT = setTimeout(() => {
      if (VW && VW.el && !VW.el.paused && !VW.seeking) VW.root.classList.add('ui-hide');
    }, 3200);
  }
}
function vwToggleUI() {
  if (!VW || VW.locked) return;
  if (VW.root.classList.contains('ui-hide')) vwShowUI();
  else if (VW.kind === 'video') { VW.root.classList.add('ui-hide'); clearTimeout(VW.hideT); }
}

async function loadItem(i) {
  if (!VW) return;
  const v = VW;
  const it = v.list[i];
  const seq = ++v.seq;
  v.idx = i;
  v.scale = 1; v.tx = 0; v.ty = 0;
  if (v.el) { try { v.el.pause(); v.el.removeAttribute('src'); v.el.load(); } catch (e) {} }
  v.el = null;
  v.kind = it.kind;
  v.root.classList.remove('mode-video', 'mode-audio', 'mode-image', 'ended');
  v.root.classList.add('mode-' + it.kind);
  vq('vw-stage').innerHTML = '';
  vq('vw-err').classList.add('hidden');
  vq('vw-name').textContent = it.name;
  vq('vw-count').textContent = (i + 1) + ' / ' + v.list.length;
  vq('vw-spin').classList.remove('hidden');
  vq('vw-pg').style.width = '0';
  vq('vw-buf').style.width = '0';
  vq('vw-knob').style.left = '0';
  vq('vw-cur').textContent = '0:00';
  vq('vw-dur').textContent = '0:00';
  vq('vw-play').textContent = '▶';
  const single = v.list.length < 2;
  vq('vw-prev').disabled = vq('vw-next').disabled = single;
  vq('vw-sl').classList.toggle('hidden', single);
  vq('vw-sr').classList.toggle('hidden', single);
  vq('vw-pip').classList.toggle('hidden', it.kind !== 'video' || !document.pictureInPictureEnabled);
  vq('vw-fit').classList.toggle('hidden', it.kind !== 'video');
  vwShowUI();
  let src, dl;
  try { [src, dl] = await Promise.all([fileLink(it.path, it.name, false), fileLink(it.path, it.name, true)]); } catch (e) { src = fileUrl(it.path, false); dl = fileUrl(it.path, true); }
  if (!VW || seq !== v.seq) return;
  const a = vq('vw-dl');
  a.href = dl;
  a.setAttribute('download', it.name);
  if (it.kind === 'image') return showImage(src, it);
  const el = document.createElement(it.kind === 'video' ? 'video' : 'audio');
  el.setAttribute('playsinline', '');
  el.preload = 'auto';
  el.autoplay = true;
  el.src = src;
  el.playbackRate = v.speed;
  v.el = el;
  if (it.kind === 'video') {
    el.style.objectFit = VW_FITS[v.fit][0];
    el.style.filter = 'brightness(' + v.bright + ')';
    vq('vw-stage').appendChild(el);
  } else {
    vq('vw-stage').innerHTML = `<div class="vw-cover"><div class="vw-disc">🎵</div><div class="vw-eq"><i></i><i></i><i></i><i></i><i></i></div><div class="vw-cn">${esc(it.name)}</div></div>`;
  }
  const key = 'pos:' + it.path;
  const saved = parseFloat(store.get(key, '0'));
  let last = 0;
  el.addEventListener('loadedmetadata', () => {
    if (seq !== v.seq) return;
    vq('vw-dur').textContent = fmtTime(el.duration);
    if (saved > 3 && saved < el.duration - 5) { try { el.currentTime = saved; vwFlash('▶ ' + fmtTime(saved), 1200); } catch (e) {} }
  });
  el.addEventListener('timeupdate', () => {
    if (seq !== v.seq) return;
    if (!v.seeking) vwProgress();
    const n = Date.now();
    if (n - last > 2000) { last = n; store.set(key, String(el.currentTime)); }
  });
  el.addEventListener('progress', () => {
    try {
      const b = el.buffered;
      if (b.length && el.duration) vq('vw-buf').style.width = (b.end(b.length - 1) / el.duration * 100) + '%';
    } catch (e) {}
  });
  el.addEventListener('play', () => { if (seq === v.seq) { vq('vw-play').textContent = '⏸'; v.root.classList.add('playing'); v.root.classList.remove('ended'); vwShowUI(); } });
  el.addEventListener('pause', () => { if (seq === v.seq) { vq('vw-play').textContent = '▶'; v.root.classList.remove('playing'); vwShowUI(); } });
  el.addEventListener('waiting', () => { if (seq === v.seq) vq('vw-spin').classList.remove('hidden'); });
  el.addEventListener('playing', () => { if (seq === v.seq) vq('vw-spin').classList.add('hidden'); });
  el.addEventListener('canplay', () => { if (seq === v.seq) vq('vw-spin').classList.add('hidden'); });
  el.addEventListener('ended', () => {
    store.set(key, '0');
    if (seq !== v.seq) return;
    if (v.idx < v.list.length - 1 && v.list[v.idx + 1].kind !== 'image') vwStep(1);
    else { v.root.classList.add('ended'); vq('vw-play').textContent = '↻'; vwShowUI(); }
  });
  el.addEventListener('error', () => {
    if (seq !== v.seq) return;
    vq('vw-spin').classList.add('hidden');
    const e = vq('vw-err');
    e.innerHTML = 'Ye file browser me nahi chal paayi (format support nahi).<br><small>Download karke VLC me chalao.</small>';
    e.classList.remove('hidden');
  });
  const p = el.play();
  if (p && p.catch) p.catch(() => { vq('vw-spin').classList.add('hidden'); });
  vq('vw-speed').textContent = v.speed + '×';
  vwMuteIcon();
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.metadata = new MediaMetadata({ title: it.name, artist: 'Qunverio Turbo' });
      navigator.mediaSession.setActionHandler('play', () => el.play());
      navigator.mediaSession.setActionHandler('pause', () => el.pause());
      navigator.mediaSession.setActionHandler('previoustrack', () => vwStep(-1));
      navigator.mediaSession.setActionHandler('nexttrack', () => vwStep(1));
      navigator.mediaSession.setActionHandler('seekbackward', () => vwSkip(-10));
      navigator.mediaSession.setActionHandler('seekforward', () => vwSkip(10));
    } catch (e) {}
  }
}

function vwProgress() {
  const el = VW && VW.el;
  if (!el) return;
  const d = el.duration || 0;
  const pct = d ? el.currentTime / d * 100 : 0;
  vq('vw-pg').style.width = pct + '%';
  vq('vw-knob').style.left = pct + '%';
  vq('vw-cur').textContent = fmtTime(el.currentTime);
  if (d) vq('vw-dur').textContent = fmtTime(d);
}

function vwStep(d) {
  if (!VW) return;
  const n = VW.idx + d;
  if (n < 0 || n >= VW.list.length) { vwFlash(d > 0 ? 'Last' : 'First', 600); return; }
  loadItem(n);
}
function vwSkip(sec) {
  const el = VW && VW.el;
  if (!el || !el.duration) return;
  el.currentTime = clamp(el.currentTime + sec, 0, el.duration);
  vwProgress();
  vwFlash(sec > 0 ? '⟳ +' + sec + 's' : '⟲ ' + sec + 's', 600);
}
function vwTogglePlay() {
  const el = VW && VW.el;
  if (!el) return;
  if (VW.root.classList.contains('ended')) { el.currentTime = 0; el.play(); return; }
  if (el.paused) el.play(); else el.pause();
}
function vwMuteIcon() {
  const el = VW && VW.el;
  const b = vq('vw-mute');
  if (b) b.textContent = el && (el.muted || el.volume === 0) ? '🔇' : '🔊';
}
function vwSetSpeed(s) {
  VW.speed = s;
  if (VW.el) VW.el.playbackRate = s;
  vq('vw-speed').textContent = s + '×';
}
function vwLock(on) {
  VW.locked = on;
  VW.root.classList.toggle('locked', on);
  if (on) { VW.root.classList.add('ui-hide'); vwFlash('🔒 Locked', 900); }
  else { vq('vw-unlock').classList.add('hidden'); vwShowUI(); }
}
async function vwFullscreen() {
  const r = VW.root;
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
      if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock();
    } else {
      await r.requestFullscreen();
      if (VW.kind === 'video' && screen.orientation && screen.orientation.lock) {
        const el = VW.el;
        if (el && el.videoWidth >= el.videoHeight) { try { await screen.orientation.lock('landscape'); } catch (e) {} }
      }
    }
  } catch (e) { vwFlash('Fullscreen nahi ho paya', 900); }
}

function vwKey(e) {
  if (!VW || /INPUT|TEXTAREA/.test((e.target || {}).tagName || '')) return;
  const k = e.key;
  if (VW.locked) return;
  if (k === 'Escape') { if (!document.fullscreenElement) closeViewer(); }
  else if (k === ' ' || k === 'k') { e.preventDefault(); vwTogglePlay(); vwShowUI(); }
  else if (k === 'ArrowRight') { e.preventDefault(); VW.kind === 'image' ? vwStep(1) : vwSkip(e.shiftKey ? 10 : 5); }
  else if (k === 'ArrowLeft') { e.preventDefault(); VW.kind === 'image' ? vwStep(-1) : vwSkip(e.shiftKey ? -10 : -5); }
  else if (k === 'l') vwSkip(10);
  else if (k === 'j') vwSkip(-10);
  else if (k === 'n') vwStep(1);
  else if (k === 'p') vwStep(-1);
  else if (k === 'f') vwFullscreen();
  else if (k === 'm' && VW.el) { VW.el.muted = !VW.el.muted; vwMuteIcon(); }
  else if ((k === 'ArrowUp' || k === 'ArrowDown') && VW.el) {
    e.preventDefault();
    VW.el.volume = clamp(VW.el.volume + (k === 'ArrowUp' ? 0.1 : -0.1), 0, 1);
    vwFlash('🔊 ' + Math.round(VW.el.volume * 100) + '%', 600);
  }
}

function showImage(src, it) {
  const v = VW;
  const img = new Image();
  img.className = 'vw-img';
  img.draggable = false;
  img.onload = () => { if (VW && VW.seq === v.seq) vq('vw-spin').classList.add('hidden'); };
  img.onerror = () => {
    vq('vw-spin').classList.add('hidden');
    const e = vq('vw-err');
    e.textContent = 'Photo nahi khul paayi';
    e.classList.remove('hidden');
  };
  img.src = src;
  vq('vw-stage').appendChild(img);
  v.img = img;
  vwApplyImg();
  // preload the next photo so swiping feels instant
  const n = v.list[v.idx + 1];
  if (n && n.kind === 'image') { const p = new Image(); p.src = fileUrl(n.path, false); }
}
function vwApplyImg(anim) {
  const v = VW;
  if (!v || !v.img) return;
  v.img.style.transition = anim ? 'transform .22s ease' : 'none';
  v.img.style.transform = `translate(${v.tx}px,${v.ty}px) scale(${v.scale})`;
}
function vwClampPan() {
  const v = VW, img = v.img;
  if (!img) return;
  const W = v.root.clientWidth, H = v.root.clientHeight;
  const mx = Math.max(0, (img.clientWidth * v.scale - W) / 2);
  const my = Math.max(0, (img.clientHeight * v.scale - H) / 2);
  v.tx = clamp(v.tx, -mx, mx);
  v.ty = clamp(v.ty, -my, my);
}

/* ---- gestures + buttons ---- */
function bindViewer() {
  const v = VW, g = vq('vw-gest');
  document.addEventListener('keydown', vwKey);
  vq('vw-back').onclick = () => closeViewer();
  vq('vw-play').onclick = () => { vwTogglePlay(); vwShowUI(); };
  vq('vw-rw').onclick = () => { vwSkip(-10); vwShowUI(); };
  vq('vw-ff').onclick = () => { vwSkip(10); vwShowUI(); };
  vq('vw-prev').onclick = () => vwStep(-1);
  vq('vw-next').onclick = () => vwStep(1);
  vq('vw-sl').onclick = () => vwStep(-1);
  vq('vw-sr').onclick = () => vwStep(1);
  vq('vw-lock').onclick = () => vwLock(true);
  vq('vw-unlock').onpointerdown = e => { e.stopPropagation(); e.preventDefault(); vwLock(false); };
  vq('vw-speed').onclick = () => {
    const i = VW_SPEEDS.indexOf(v.speed);
    vwSetSpeed(VW_SPEEDS[(i + 1) % VW_SPEEDS.length]);
    vwFlash(v.speed + '×', 700);
    vwShowUI();
  };
  vq('vw-fit').onclick = () => {
    v.fit = (v.fit + 1) % VW_FITS.length;
    if (v.el) v.el.style.objectFit = VW_FITS[v.fit][0];
    vq('vw-fit').textContent = VW_FITS[v.fit][1];
    vwShowUI();
  };
  vq('vw-mute').onclick = () => { if (v.el) { v.el.muted = !v.el.muted; vwMuteIcon(); } vwShowUI(); };
  vq('vw-pip').onclick = async () => {
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else if (v.el) await v.el.requestPictureInPicture();
    } catch (e) { vwFlash('PiP nahi chala', 800); }
  };
  vq('vw-fs').onclick = vwFullscreen;

  // seek bar (drag or tap)
  const sk = vq('vw-seek');
  const at = e => {
    const r = sk.getBoundingClientRect();
    return clamp((e.clientX - r.left) / r.width, 0, 1);
  };
  const bub = vq('vw-bubble');
  sk.addEventListener('pointerdown', e => {
    if (!v.el || !v.el.duration) return;
    v.seeking = true;
    sk.setPointerCapture(e.pointerId);
    const p = at(e);
    vq('vw-pg').style.width = p * 100 + '%';
    vq('vw-knob').style.left = p * 100 + '%';
    bub.textContent = fmtTime(p * v.el.duration);
    bub.style.left = p * 100 + '%';
    bub.classList.remove('hidden');
    v.seekTo = p;
  });
  sk.addEventListener('pointermove', e => {
    if (!v.seeking) return;
    const p = at(e);
    v.seekTo = p;
    vq('vw-pg').style.width = p * 100 + '%';
    vq('vw-knob').style.left = p * 100 + '%';
    bub.textContent = fmtTime(p * v.el.duration);
    bub.style.left = p * 100 + '%';
    vq('vw-cur').textContent = fmtTime(p * v.el.duration);
  });
  const endSeek = () => {
    if (!v.seeking) return;
    v.seeking = false;
    bub.classList.add('hidden');
    if (v.el && v.el.duration) v.el.currentTime = v.seekTo * v.el.duration;
    vwShowUI();
  };
  sk.addEventListener('pointerup', endSeek);
  sk.addEventListener('pointercancel', endSeek);

  // gesture layer
  const pts = new Map();
  let st = null;
  const tapAction = x => {
    const W = v.root.clientWidth;
    if (v.locked) {
      const u = vq('vw-unlock');
      u.classList.remove('hidden');
      clearTimeout(v.unT);
      v.unT = setTimeout(() => u.classList.add('hidden'), 2500);
      return;
    }
    if (v.kind === 'image') { vwToggleUI(); return; }
    if (v.kind === 'audio') { vwToggleUI(); return; }
    vwToggleUI();
    void x; void W;
  };
  const doubleTap = x => {
    const W = v.root.clientWidth;
    if (v.locked) return;
    if (v.kind === 'image') {
      if (v.scale > 1) { v.scale = 1; v.tx = 0; v.ty = 0; }
      else {
        v.scale = 2.6;
        const cx = W / 2, cy = v.root.clientHeight / 2;
        v.tx = (cx - x.x) * 1.6; v.ty = (cy - x.y) * 1.6;
        vwClampPan();
      }
      vwApplyImg(true);
    } else if (v.kind === 'video') {
      const f = x.x / W;
      if (f < 0.35) vwSkip(-10);
      else if (f > 0.65) vwSkip(10);
      else vwTogglePlay();
    }
  };
  const tap = (x, y) => {
    const now = Date.now();
    if (now - v.lastTap < 300) {
      clearTimeout(v.tapT);
      v.lastTap = 0;
      doubleTap({ x, y });
    } else {
      v.lastTap = now;
      clearTimeout(v.tapT);
      v.tapT = setTimeout(() => tapAction(x), 300);
    }
  };

  g.addEventListener('pointerdown', e => {
    g.setPointerCapture(e.pointerId);
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 1) {
      st = {
        x: e.clientX, y: e.clientY, t: Date.now(), mode: null, moved: false, long: false,
        ct: v.el ? v.el.currentTime : 0, vol: v.el ? v.el.volume : 1, br: v.bright,
        tx: v.tx, ty: v.ty, lp: null, pinch: 0, sc: v.scale
      };
      if (!v.locked && v.kind === 'video') {
        st.lp = setTimeout(() => {
          if (!st || st.moved) return;
          st.long = true;
          if (v.el) v.el.playbackRate = 2;
          vwFlash('▶▶ 2×', 1200);
        }, 450);
      }
    } else if (pts.size === 2 && v.kind === 'image' && !v.locked) {
      const a = Array.from(pts.values());
      st.pinch = Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y);
      st.sc = v.scale;
      st.mode = 'pinch';
    }
  });
  g.addEventListener('pointermove', e => {
    if (!pts.has(e.pointerId) || !st) return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (v.locked) return;
    if (st.mode === 'pinch' && pts.size >= 2) {
      const a = Array.from(pts.values());
      const d = Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y);
      v.scale = clamp(st.sc * d / st.pinch, 1, 6);
      vwClampPan();
      vwApplyImg();
      return;
    }
    if (pts.size > 1) return;
    const dx = e.clientX - st.x, dy = e.clientY - st.y;
    const W = v.root.clientWidth, H = v.root.clientHeight;
    if (!st.moved && Math.hypot(dx, dy) > 12) {
      st.moved = true;
      clearTimeout(st.lp);
      if (v.kind === 'image') st.mode = v.scale > 1 ? 'pan' : 'swipe';
      else if (v.kind === 'video') st.mode = Math.abs(dx) > Math.abs(dy) ? 'seek' : (st.x < W / 2 ? 'bright' : 'vol');
      else st.mode = 'none';
    }
    if (!st.moved) return;
    if (st.mode === 'pan') {
      v.tx = st.tx + dx; v.ty = st.ty + dy;
      vwClampPan();
      vwApplyImg();
    } else if (st.mode === 'swipe') {
      v.img && (v.img.style.transition = 'none', v.img.style.transform = `translate(${dx}px,0) scale(1)`);
    } else if (st.mode === 'seek' && v.el && v.el.duration) {
      const span = Math.min(v.el.duration, 120);
      const t = clamp(st.ct + dx / W * span, 0, v.el.duration);
      st.seekT = t;
      const diff = Math.round(t - st.ct);
      vwFlash(`<b>${fmtTime(t)}</b><small>${diff >= 0 ? '+' : ''}${diff}s</small>`, 5000);
    } else if (st.mode === 'bright') {
      v.bright = clamp(st.br - dy / H * 1.4, 0.25, 1.8);
      if (v.el) v.el.style.filter = 'brightness(' + v.bright + ')';
      vwFlash('☀ ' + Math.round(v.bright * 100) + '%', 700);
    } else if (st.mode === 'vol' && v.el) {
      v.el.volume = clamp(st.vol - dy / H * 1.4, 0, 1);
      if (v.el.volume > 0) v.el.muted = false;
      vwMuteIcon();
      vwFlash('🔊 ' + Math.round(v.el.volume * 100) + '%', 700);
    }
  });
  const up = e => {
    try { g.releasePointerCapture(e.pointerId); } catch (x) {}
    if (!pts.has(e.pointerId)) return;
    pts.delete(e.pointerId);
    if (!st) return;
    if (pts.size > 0) return;
    clearTimeout(st.lp);
    const s = st;
    st = null;
    if (v.locked) { if (!s.moved) tap(s.x, s.y); return; }
    if (s.long) { if (v.el) v.el.playbackRate = v.speed; vq('vw-flash').classList.add('hidden'); return; }
    if (s.mode === 'pinch') { if (v.scale < 1.05) { v.scale = 1; v.tx = 0; v.ty = 0; vwApplyImg(true); } return; }
    if (!s.moved) { tap(e.clientX, e.clientY); return; }
    if (s.mode === 'seek' && s.seekT != null && v.el) { v.el.currentTime = s.seekT; vwProgress(); vq('vw-flash').classList.add('hidden'); }
    if (s.mode === 'swipe') {
      const dx = e.clientX - s.x;
      if (Math.abs(dx) > 70) vwStep(dx < 0 ? 1 : -1);
      else vwApplyImg(true);
    }
  };
  g.addEventListener('pointerup', up);
  g.addEventListener('pointercancel', up);
  g.addEventListener('wheel', e => {
    if (v.kind !== 'image') return;
    e.preventDefault();
    v.scale = clamp(v.scale * (e.deltaY < 0 ? 1.15 : 1 / 1.15), 1, 6);
    if (v.scale === 1) { v.tx = 0; v.ty = 0; }
    vwClampPan();
    vwApplyImg();
  }, { passive: false });
  g.addEventListener('mousemove', () => { if (!v.locked) vwShowUI(); });
}


const doSearch = guard(async function () {
  const q = $('#search').value.trim();
  if (!q) { searchMode = false; return loadDir(cur); }
  const r = await api('/api/search?q=' + encodeURIComponent(q));
  searchMode = true;
  $('#crumbs').innerHTML = `<span class="muted">🔎 "${esc(q)}"</span> <a data-path="${esc(cur)}">✕</a>`;
  renderFiles(r.items);
});

/* ---------- upload (chunked, resumable, auto-retry) ---------- */
const CHUNK = 8 * 1024 * 1024;
const CHUNK_FAST = 32 * 1024 * 1024;
const queue = [];
let activeUploads = 0;

function addFiles(files) {
  for (const f of files) queue.push({ file: f, dir: cur });
  runQueue();
}
function runQueue() {
  while (activeUploads < 2 && queue.length) {
    const job = queue.shift();
    activeUploads++;
    uploadOne(job).finally(() => {
      activeUploads--;
      if (!queue.length && !activeUploads) {
        if (view === 'files' && !searchMode) loadDir(cur);
      } else {
        runQueue();
      }
    });
  }
}
function putChunk(url, blob, onProg, fast) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open(fast ? 'POST' : 'PUT', url);
    if (!fast) x.setRequestHeader('X-QC', '1');
    x.responseType = 'json';
    x.upload.onprogress = e => { if (e.lengthComputable) onProg(e.loaded); };
    x.onload = () => resolve({ status: x.status, data: x.response || {} });
    x.onerror = () => reject(new Error('net'));
    x.ontimeout = () => reject(new Error('net'));
    x.timeout = 120000;
    x.send(blob);
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function uploadOne(job) {
  const f = job.file, total = f.size;
  const el = document.createElement('div');
  el.className = 'up';
  el.innerHTML = `<div class="top"><span>⬆ ${esc(f.name)}</span><span class="st small muted"></span></div><div class="bar"><div></div></div>`;
  $('#uploads').appendChild(el);
  const bar = $('.bar>div', el), st = $('.st', el);
  const q = (extra) => `dir=${encodeURIComponent(job.dir)}&name=${encodeURIComponent(f.name)}&total=${total}` + (extra || '');
  const t0 = Date.now();
  let offset = 0, tries = 0;
  let fast = null;
  const getOffset = async () => {
    if (fast) {
      try {
        const r = await fetch(fast.base + '/us/' + fast.token + '?' + q());
        if (r.ok) return (await r.json()).offset || 0;
        fast = null;
      } catch (e) { fast = null; }
    }
    try { return (await api('/api/upload/status?' + q())).offset || 0; } catch (e) { if (e && e.status === 403) throw e; return 0; }
  };
  try {
    if (location.protocol === 'http:') {
      try { const t = await api('/api/ticket?path=&write=1'); fast = { base: fastHost(t.port), token: t.token }; } catch (e) { if (e && e.status === 403) throw e; }
    }
    offset = await getOffset();
    if (offset > total) offset = 0;
    while (true) {
      const end = Math.min(offset + (fast ? CHUNK_FAST : CHUNK), total);
      const blob = f.slice(offset, end);
      let res;
      try {
        res = await putChunk(fast ? fast.base + '/u/' + fast.token + '?' + q('&offset=' + offset) : '/api/upload?' + q('&offset=' + offset), blob, loaded => {
          const done = offset + loaded;
          bar.style.width = (total ? done / total * 100 : 100) + '%';
          const sp = done / Math.max(1, (Date.now() - t0) / 1000);
          st.textContent = `${fmtSize(done)} / ${fmtSize(total)} · ${fmtSpeed(sp)}`;
        }, !!fast);
      } catch (e) {
        // network dropped: wait, ask the server where we are, continue
        if (++tries > 40) throw { error: 'Network error' };
        if (fast && tries >= 2) fast = null;
        st.textContent = T('retry');
        await sleep(Math.min(8000, 1000 * tries));
        try { offset = await getOffset(); } catch (e2) {}
        continue;
      }
      if (fast && (res.status === 403 || res.status === 404)) { fast = null; offset = await getOffset(); continue; }
      if (res.status === 409) { offset = res.data.offset || 0; continue; }
      if (res.status === 401) { showLogin(); throw { error: 'Login karo' }; }
      if (res.status === 503) { await sleep(2000); continue; }
      if (res.status < 200 || res.status >= 300) throw { error: res.data.error || 'Upload fail' };
      tries = 0;
      offset = res.data.offset;
      if (res.data.done) break;
    }
    bar.style.width = '100%';
    st.textContent = T('done');
    setTimeout(() => el.remove(), 2500);
  } catch (e) {
    st.textContent = T('failed') + ': ' + ((e && e.error) || '');
    st.style.color = 'var(--bad)';
    setTimeout(() => el.remove(), 8000);
  }
}

/* ---------- share links ---------- */
const shareDialog = guard(async function (path, name) {
  const b = modal(`<h3>🔗 ${esc(name)}</h3><p class="small muted">${esc(T('share_hint'))}</p>
    <div class="row wrap"><button class="ghost" data-h="1">${T('dur1')}</button><button class="ghost" data-h="24">${T('dur24')}</button><button class="ghost" data-h="168">${T('dur168')}</button></div>
    <div id="share-out" style="margin-top:12px"></div>
    <div class="modal-actions"><button class="primary" id="sh-close">${T('close')}</button></div>`);
  $('#sh-close', b).onclick = closeModal;
  b.onclick = guard(async e => {
    const h = e.target.closest('[data-h]');
    if (!h) return;
    const r = await api('/api/share', { body: { path, hours: parseInt(h.dataset.h, 10) } });
    const s = await api('/api/status');
    const bases = s.addresses.map(a => a.url);
    if (s.remoteUrl) bases.push(s.remoteUrl.replace(/\/+$/, ''));
    $('#share-out', b).innerHTML = bases.map(u => {
      const link = u + r.url;
      return `<div class="addr"><div class="small">${esc(link)}</div><button class="ghost" data-copy="${esc(link)}">${T('copy')}</button></div>`;
    }).join('');
  });
});
const loadShares = guard(async function () {
  const r = await api('/api/shares');
  $('#share-list').innerHTML = r.shares.length ? r.shares.map(s => `
    <div class="dev" data-token="${esc(s.token)}">
      <div class="info"><div>${s.dir ? '📁' : '📄'} <b>${esc(s.name)}</b></div>
      <div class="small muted">${T('link_exp')}: ${esc(fmtDate(s.expires))} · ${esc(s.by)}</div></div>
      <button class="ghost danger" data-act="srev">${T('revoke')}</button>
    </div>`).join('') : `<p class="muted small">${T('no_shares')}</p>`;
});

/* ---------- devices ---------- */
const loadDevices = guard(async function () {
  const r = await api('/api/devices');
  $('#dev-list').innerHTML = r.devices.map(d => `
    <div class="dev" data-id="${esc(d.id)}">
      <div class="info">
        <div><span class="dot ${d.online ? 'on' : ''}"></span><b>${esc(d.name)}</b> ${d.self ? `<span class="tag">${T('you')}</span>` : ''} ${d.admin ? `<span class="tag">${T('admin')}</span>` : `<span class="tag">${T('paired')}</span>`}</div>
        <div class="small muted">${esc(d.ip)} · ${T('last_seen')}: ${d.online ? T('online') : ago(d.lastSeen)}</div>
      </div>
      ${d.admin ? '' : `<label class="small"><input type="checkbox" data-act="write" ${d.canWrite ? 'checked' : ''}> ${T('can_write')}</label>`}
      ${d.self ? '' : `<button class="ghost danger" data-act="rm">${T('remove')}</button>`}
    </div>`).join('');
});

/* ---------- settings ---------- */
const loadSettings = guard(async function () {
  const s = await api('/api/status');
  $('#set-name').value = s.name;
  $('#set-remote').value = s.remoteUrl || '';
  if (s.guest) {
    $('#g-enabled').checked = s.guest.enabled;
    $('#g-folder').value = s.guest.folder;
    $('#g-upload').checked = s.guest.upload;
    $('#g-delete').checked = s.guest.delete;
    $('#g-hours').value = '-1';
    $('#g-until').textContent = !s.guest.enabled ? 'Abhi guest access BAND hai' :
      (s.guest.until ? 'Guest access ' + new Date(s.guest.until).toLocaleString() + ' tak' : 'Guest access: jab tak aap band na karo');
  }
  pollStatusOnce(s);
});
function pollStatusOnce(s) {
  $('#about-text').innerHTML =
    `${T('mode')}: ${s.storageMode === 'public' ? T('pub_mode') : T('app_mode')}<br>${T('root')}: ${esc(s.root)}<br>${T('ver')}: 2.1.0`;
}

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const nav = e.target.closest('.nav[data-view]');
  if (nav) { go(nav.dataset.view); return; }
  const cp = e.target.closest('[data-copy]');
  if (cp) {
    const v = cp.dataset.copy;
    (navigator.clipboard ? navigator.clipboard.writeText(v) : Promise.reject()).then(() => toast('Copy ho gaya'), () => toast(v));
    return;
  }
  const cr = e.target.closest('.crumbs a');
  if (cr) { loadDir(cr.dataset.path); return; }
  const fa = e.target.closest('.f [data-act]');
  if (fa) { fileAction(fa.closest('.f'), fa.dataset.act); return; }
  const da = e.target.closest('.dev button[data-act="rm"]');
  if (da) {
    const id = da.closest('.dev').dataset.id;
    confirmBox(T('confirm_rm')).then(ok => { if (ok) guard(async () => { await api('/api/device/remove', { body: { id } }); loadDevices(); })(); });
    return;
  }
  const sr = e.target.closest('.dev button[data-act="srev"]');
  if (sr) {
    guard(async () => { await api('/api/share/revoke', { body: { token: sr.closest('.dev').dataset.token } }); loadShares(); })();
    return;
  }
  if (e.target === $('#modal')) closeModal();
});
document.addEventListener('change', e => {
  const c = e.target.closest('.dev input[data-act="write"]');
  if (c) guard(async () => { await api('/api/device/write', { body: { id: c.closest('.dev').dataset.id, value: c.checked } }); })();
});

$('#tab-pw').onclick = () => setLoginMode('pw');
$('#tab-code').onclick = () => setLoginMode('code');
$('#tab-guest').onclick = () => setLoginMode('guest');
$('#login-btn').onclick = doLogin;
['pw', 'code', 'dev-name'].forEach(id => $('#' + id).addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); }));
$('#dev-name').value = store.get('qc_devname', defaultName());
$('#logout').onclick = async () => { try { await api('/api/logout', { method: 'POST', body: {} }); } catch (e) {} showLogin(); };

$('#btn-upload').onclick = () => $('#file-input').click();
$('#file-input').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
$('#btn-view').onclick = () => {
  store.set('qc_view', store.get('qc_view', 'list') === 'grid' ? 'list' : 'grid');
  $('#file-list').classList.toggle('grid', store.get('qc_view', 'list') === 'grid');
};
$('#btn-mkdir').onclick = guard(async () => {
  const n = await ask(T('folder_name'), '', T('create'));
  if (n) { await api('/api/mkdir', { body: { path: cur, name: n } }); loadDir(cur); }
});
let st;
$('#search').addEventListener('input', () => { clearTimeout(st); st = setTimeout(doSearch, 300); });

let dragN = 0;
window.addEventListener('dragenter', e => { if (view === 'files' && e.dataTransfer && e.dataTransfer.types.includes('Files')) { dragN++; $('#drop').classList.remove('hidden'); } });
window.addEventListener('dragleave', () => { dragN = Math.max(0, dragN - 1); if (!dragN) $('#drop').classList.add('hidden'); });
window.addEventListener('dragover', e => e.preventDefault());
window.addEventListener('drop', e => {
  e.preventDefault(); dragN = 0; $('#drop').classList.add('hidden');
  if (view === 'files' && e.dataTransfer && e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
});
window.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

$('#revoke-all').onclick = guard(async () => {
  if (await confirmBox(T('revoke_all') + '?')) { await api('/api/device/revoke-others', { body: {} }); loadDevices(); }
});
$('#theme-btn').onclick = () => setTheme(document.documentElement.dataset.theme === 'light' ? 'dark' : 'light');
$('#lang-btn').onclick = () => { lang = lang === 'hi' ? 'en' : 'hi'; store.set('qc_lang', lang); applyLang(); go(view); };
$('#save-settings').onclick = guard(async () => {
  await api('/api/settings', { body: { name: $('#set-name').value, remoteUrl: $('#set-remote').value } });
  toast(T('saved'));
  $('#brand-name').textContent = $('#set-name').value || 'Qunverio Turbo';
});
$('#g-pick').onclick = guard(async () => {
  const p = await pickFolder('Guest folder chuno');
  if (p) $('#g-folder').value = p;
});
$('#g-save').onclick = guard(async () => {
  const body = {
    guestEnabled: $('#g-enabled').checked, guestFolder: $('#g-folder').value,
    guestUpload: $('#g-upload').checked, guestDelete: $('#g-delete').checked
  };
  const hrs = parseInt($('#g-hours').value, 10);
  if (hrs >= 0) body.guestHours = hrs;
  const gp = $('#g-pw').value;
  if (gp) body.guestPassword = gp;
  await api('/api/settings', { body });
  $('#g-pw').value = '';
  toast(T('saved'));
  loadSettings();
});
$('#save-pw').onclick = guard(async () => {
  await api('/api/password', { body: { old: $('#pw-old').value, new: $('#pw-new').value } });
  $('#pw-old').value = ''; $('#pw-new').value = '';
  toast(T('saved'));
});

async function measure(url, onTick) {
  const t0 = performance.now();
  let got = 0;
  const r = await fetch(url, { credentials: 'same-origin' });
  const rd = r.body.getReader();
  for (;;) {
    const x = await rd.read();
    if (x.done) break;
    got += x.value.length;
    onTick(got / 1048576 / ((performance.now() - t0) / 1000));
  }
  return got / 1048576 / ((performance.now() - t0) / 1000);
}
async function measureMulti(url, n, onTick) {
  const t0 = performance.now();
  let got = 0;
  await Promise.all(Array.from({ length: n }, async () => {
    const r = await fetch(url, { credentials: 'same-origin' });
    const rd = r.body.getReader();
    for (;;) {
      const x = await rd.read();
      if (x.done) break;
      got += x.value.length;
      onTick(got / 1048576 / ((performance.now() - t0) / 1000));
    }
  }));
  return got / 1048576 / ((performance.now() - t0) / 1000);
}
$('#speed-btn').onclick = guard(async () => {
  const out = $('#speed-out');
  if (location.protocol !== 'http:') { toast(T('speed_https')); return; }
  const btn = $('#speed-btn');
  btn.disabled = true;
  try {
    let fastR = '-', normR = '-';
    try {
      const t = await api('/api/ticket?path=');
      fastR = (await measure(fastHost(t.port) + '/z/' + t.token + '?mb=300', v => { out.textContent = T('speed_fast') + ': ' + v.toFixed(1) + ' MB/s ...'; })).toFixed(1) + ' MB/s';
    } catch (e) { fastR = '-'; }
    let multiR = '-';
    try {
      const t2 = await api('/api/ticket?path=');
      multiR = (await measureMulti(fastHost(t2.port) + '/z/' + t2.token + '?mb=100', 4, v => { out.textContent = T('speed_fast') + ': ' + fastR + ' · 4 stream: ' + v.toFixed(1) + ' MB/s ...'; })).toFixed(1) + ' MB/s';
    } catch (e) { multiR = '-'; }
    out.textContent = T('speed_fast') + ': ' + fastR + ' ...';
    normR = (await measure('/api/zero?mb=300', v => { out.textContent = T('speed_fast') + ': ' + fastR + ' · ' + T('speed_norm') + ': ' + v.toFixed(1) + ' MB/s ...'; })).toFixed(1) + ' MB/s';
    out.innerHTML = '<b>' + esc(T('speed_fast')) + ': ' + esc(fastR) + '</b><br>Fast 4-stream: ' + esc(multiR) + '<br>' + esc(T('speed_norm')) + ': ' + esc(normR);
  } finally { btn.disabled = false; }
});

applyLang();
boot();
})();
