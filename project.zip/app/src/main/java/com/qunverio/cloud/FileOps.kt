package com.qunverio.cloud

import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

class FsError(msg: String) : Exception(msg)

/** All file operations. Every path from the network goes through resolve() first. */
object FileOps {
    const val TMP = ".qc_tmp"

    @Volatile
    var used = 0L
        private set

    fun root(): File = Store.rootDir().canonicalFile

    /** Turns a web path into a File inside the root, or null if it tries to escape (../, symlinks). */
    fun resolve(rel: String?, base: File = root()): File? {
        val root = base
        val clean = (rel ?: "").replace('\\', '/').trim('/')
        if (clean.isEmpty()) return root
        val parts = clean.split('/')
        if (parts.any { it == ".." || it.contains('\u0000') }) return null
        val f = File(root, clean).canonicalFile
        if (f.path != root.path && !f.path.startsWith(root.path + File.separator)) return null
        val rp = f.path.removePrefix(root.path).trim(File.separatorChar)
        if (rp.isNotEmpty() && rp.split(File.separatorChar).first().equals(TMP, true)) return null
        return f
    }

    /** Folder a device may see: whole cloud for admin, only the guest folder for guests. Null = no access. */
    fun baseFor(deviceId: String): File? {
        val d = Store.deviceById(deviceId)
        if (d == null || d.admin) return root()
        if (!Store.guestActive()) return null
        val b = resolve(Store.guestFolder) ?: return null
        if (b.path == root().path) return null
        b.mkdirs()
        return if (b.isDirectory) b else null
    }

    fun baseOf(d: Store.Device): File = baseFor(d.id) ?: root()

    fun rel(root: File, f: File): String =
        f.path.removePrefix(root.path).trim(File.separatorChar).replace(File.separatorChar, '/')

    /** Safe file name: no slashes or control characters, not empty, not too long. */
    fun cleanName(n: String): String? {
        val s = n.replace(Regex("[\\u0000-\\u001f\\\\/:*?\"<>|]"), "_").trim().trim('.')
        if (s.isEmpty() || s.length > 200) return null
        if (s.equals(TMP, true)) return null
        return s
    }

    fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            f = File(dir, "$base ($i)$ext")
            if (!f.exists()) return f
            i++
        }
    }

    fun uploadId(deviceId: String, dirRel: String, name: String, total: Long): String {
        val md = MessageDigest.getInstance("SHA-1")
        val h = md.digest("$deviceId|$dirRel|$name|$total".toByteArray())
        return h.joinToString("") { "%02x".format(it) }.take(24)
    }

    fun mime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isEmpty()) return "application/octet-stream"
        val m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        if (m != null) return m
        return when (ext) {
            "mkv" -> "video/x-matroska"
            "m4a" -> "audio/mp4"
            "flac" -> "audio/flac"
            "opus" -> "audio/ogg"
            "webm" -> "video/webm"
            else -> "application/octet-stream"
        }
    }

    /** Only media/pdf may open inline in the browser. Everything else (html, svg, js...) is forced to download. */
    fun inlineSafe(m: String): Boolean =
        m.startsWith("video/") || m.startsWith("audio/") ||
            (m.startsWith("image/") && !m.contains("svg")) || m == "application/pdf"

    private fun item(root: File, f: File): JSONObject = JSONObject()
        .put("name", f.name)
        .put("path", rel(root, f))
        .put("dir", f.isDirectory)
        .put("size", if (f.isFile) f.length() else 0L)
        .put("mtime", f.lastModified())

    fun list(dir: File, base: File = root()): JSONArray {
        val root = base
        val arr = JSONArray()
        val files = dir.listFiles() ?: return arr
        val sorted = files
            .filter { !(dir.path == root.path && it.name.equals(TMP, true)) }
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
        for (f in sorted) arr.put(item(root, f))
        return arr
    }

    fun search(q: String, base: File = root(), limit: Int = 200): JSONArray {
        val root = base
        val arr = JSONArray()
        val needle = q.lowercase()
        if (needle.isEmpty()) return arr
        val seq = root.walkTopDown().maxDepth(12)
            .onEnter { !(it.parentFile?.path == root.path && it.name.equals(TMP, true)) }
        for (f in seq) {
            if (f.path == root.path) continue
            if (f.name.lowercase().contains(needle)) {
                arr.put(item(root, f))
                if (arr.length() >= limit) break
            }
        }
        return arr
    }

    fun mkdir(parent: File, name: String): File {
        val n = cleanName(name) ?: throw FsError("Folder ka naam sahi nahi hai")
        val d = File(parent, n)
        if (d.exists()) throw FsError("Is naam ka item pehle se hai")
        if (!d.mkdir()) throw FsError("Folder nahi ban paya")
        return d
    }

    fun rename(f: File, name: String, base: File = root()): File {
        if (f.path == base.path) throw FsError("Root folder rename nahi ho sakta")
        val n = cleanName(name) ?: throw FsError("Naam sahi nahi hai")
        val t = File(f.parentFile, n)
        if (t.exists()) throw FsError("Is naam ka item pehle se hai")
        if (!f.renameTo(t)) throw FsError("Rename nahi ho paya")
        return t
    }

    fun move(f: File, destDir: File, base: File = root()): File {
        if (f.path == base.path) throw FsError("Root folder move nahi ho sakta")
        if (!destDir.isDirectory) throw FsError("Destination folder nahi mila")
        if (f.isDirectory && (destDir.path == f.path || destDir.path.startsWith(f.path + File.separator))) {
            throw FsError("Folder ko apne andar move nahi kar sakte")
        }
        if (f.parentFile?.path == destDir.path) return f
        val t = unique(destDir, f.name)
        if (!f.renameTo(t)) {
            if (f.isDirectory) f.copyRecursively(t, false) else f.copyTo(t, false)
            f.deleteRecursively()
        }
        return t
    }

    fun delete(f: File, base: File = root()) {
        if (f.path == base.path) throw FsError("Root folder delete nahi ho sakta")
        if (!f.deleteRecursively()) throw FsError("Delete nahi ho paya")
    }

    @Volatile private var lastRefresh = 0L

    /** Recounts used space in the background, at most once per maxAgeMs. */
    fun refreshIfStale(maxAgeMs: Long) {
        val now = System.currentTimeMillis()
        if (now - lastRefresh < maxAgeMs) return
        lastRefresh = now
        Thread { refreshUsed() }.start()
    }

    /** Called from a background thread. Walks the cloud folder and sums file sizes. */
    fun refreshUsed() {
        var sum = 0L
        try {
            for (f in root().walkTopDown()) if (f.isFile) sum += f.length()
        } catch (e: Exception) {
            return
        }
        used = sum
    }

    /** Deletes half-finished uploads older than 7 days. */
    fun cleanTmp() {
        val d = File(root(), TMP)
        val limit = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        d.listFiles()?.forEach { if (it.lastModified() < limit) it.delete() }
    }
}
