package com.qunverio.cloud

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Settings, password, devices and sessions. Saved in SharedPreferences. */
object Store {

    class Device(
        val id: String,
        var name: String,
        val created: Long,
        var lastSeen: Long,
        var ip: String,
        var canWrite: Boolean,
        val admin: Boolean,
        var ua: String
    ) {
        fun toJson(now: Long = System.currentTimeMillis()): JSONObject = JSONObject()
            .put("id", id)
            .put("name", name)
            .put("created", created)
            .put("lastSeen", lastSeen)
            .put("ip", ip)
            .put("canWrite", canWrite)
            .put("admin", admin)
            .put("online", now - lastSeen < 60_000)
            .put("ua", ua)
    }

    private class Sess(val deviceId: String, var expires: Long)

    private const val SESSION_MS = 30L * 24 * 3600 * 1000

    private lateinit var sp: SharedPreferences
    private lateinit var app: Context
    private val rnd = SecureRandom()
    private val devices = LinkedHashMap<String, Device>()
    private val sessions = HashMap<String, Sess>()
    private var lastSave = 0L

    @Synchronized
    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        app = ctx.applicationContext
        sp = app.getSharedPreferences("qc", Context.MODE_PRIVATE)
        loadAuth()
    }

    // ---------- simple settings ----------
    var port: Int
        get() = sp.getInt("port", 8080)
        set(v) { sp.edit().putInt("port", v).apply() }

    var serverName: String
        get() = sp.getString("server_name", "Qunverio Turbo") ?: "Qunverio Turbo"
        set(v) { sp.edit().putString("server_name", v).apply() }

    var remoteUrl: String
        get() = sp.getString("remote_url", "") ?: ""
        set(v) { sp.edit().putString("remote_url", v).apply() }

    var publicStorage: Boolean
        get() = sp.getBoolean("public_storage", false)
        set(v) { sp.edit().putBoolean("public_storage", v).apply() }

    /** True when the user wants the server running (used to restore after Android kills the service). */
    var wantRunning: Boolean
        get() = sp.getBoolean("want_running", false)
        set(v) { sp.edit().putBoolean("want_running", v).apply() }

    // ---------- guest access (admin controls these) ----------
    var guestEnabled: Boolean
        get() = sp.getBoolean("g_enabled", true)
        set(v) { sp.edit().putBoolean("g_enabled", v).apply() }

    /** Folder (relative to the cloud root) that guests are locked into. */
    var guestFolder: String
        get() = sp.getString("g_folder", "Guest") ?: "Guest"
        set(v) { sp.edit().putString("g_folder", v).apply() }

    var guestUpload: Boolean
        get() = sp.getBoolean("g_upload", true)
        set(v) { sp.edit().putBoolean("g_upload", v).apply() }

    /** Guests may delete / rename / move inside their folder. */
    var guestDelete: Boolean
        get() = sp.getBoolean("g_delete", false)
        set(v) { sp.edit().putBoolean("g_delete", v).apply() }

    /** 0 = until admin switches off, otherwise epoch ms when guest access ends. */
    var guestUntil: Long
        get() = sp.getLong("g_until", 0L)
        set(v) { sp.edit().putLong("g_until", v).apply() }

    fun guestActive(): Boolean =
        guestEnabled && guestFolder.isNotBlank() && (guestUntil == 0L || System.currentTimeMillis() < guestUntil)

    fun canUpload(d: Device): Boolean = d.admin || (d.canWrite && guestUpload)
    fun canManage(d: Device): Boolean = d.admin || guestDelete

    val hasGuestPassword: Boolean get() = sp.contains("gpw_hash")

    fun setGuestPassword(pw: String) {
        if (pw.isEmpty()) {
            sp.edit().remove("gpw_hash").remove("gpw_salt").apply()
            return
        }
        val salt = ByteArray(16)
        rnd.nextBytes(salt)
        sp.edit().putString("gpw_salt", hex(salt)).putString("gpw_hash", hex(pbkdf2(pw, salt))).apply()
    }

    fun checkGuestPassword(pw: String): Boolean {
        val s = sp.getString("gpw_salt", null) ?: return false
        val h = sp.getString("gpw_hash", null) ?: return false
        return MessageDigest.isEqual(unhex(h), pbkdf2(pw, unhex(s)))
    }

    @Synchronized
    fun deviceById(id: String): Device? = devices[id]

    val hasPassword: Boolean get() = sp.contains("pw_hash")

    fun getString(k: String, d: String): String = sp.getString(k, d) ?: d

    fun putString(k: String, v: String) {
        sp.edit().putString(k, v).apply()
    }

    // ---------- storage root ----------
    fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else app.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun usingPublic(): Boolean = publicStorage && hasAllFiles()

    fun rootDir(): File {
        val base: File = if (usingPublic()) Environment.getExternalStorageDirectory()
        else (app.getExternalFilesDir(null) ?: app.filesDir)
        val d = File(base, "QunverioTurbo")
        d.mkdirs()
        return d
    }

    // ---------- password ----------
    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String): ByteArray =
        ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    private fun pbkdf2(pw: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun setPassword(pw: String) {
        val salt = ByteArray(16)
        rnd.nextBytes(salt)
        sp.edit()
            .putString("pw_salt", hex(salt))
            .putString("pw_hash", hex(pbkdf2(pw, salt)))
            .apply()
    }

    fun checkPassword(pw: String): Boolean {
        val s = sp.getString("pw_salt", null) ?: return false
        val h = sp.getString("pw_hash", null) ?: return false
        return MessageDigest.isEqual(unhex(h), pbkdf2(pw, unhex(s)))
    }

    // ---------- devices & sessions ----------
    private fun sha(s: String): String =
        hex(MessageDigest.getInstance("SHA-256").digest(s.toByteArray()))

    private fun randomHex(n: Int): String {
        val b = ByteArray(n)
        rnd.nextBytes(b)
        return hex(b)
    }

    @Synchronized
    fun createSession(name: String, ip: String, ua: String, admin: Boolean, canWrite: Boolean = true): Pair<String, Device> {
        val now = System.currentTimeMillis()
        val id = randomHex(6)
        val d = Device(id, name, now, now, ip, canWrite, admin, ua.take(200))
        devices[id] = d
        val token = randomHex(32)
        sessions[sha(token)] = Sess(id, now + SESSION_MS)
        saveAuth()
        return Pair(token, d)
    }

    @Synchronized
    fun sessionFor(token: String, ip: String): Device? {
        val h = sha(token)
        val s = sessions[h] ?: return null
        val now = System.currentTimeMillis()
        if (now > s.expires) {
            sessions.remove(h)
            saveAuth()
            return null
        }
        val d = devices[s.deviceId]
        if (d == null) {
            sessions.remove(h)
            return null
        }
        d.lastSeen = now
        d.ip = ip
        s.expires = now + SESSION_MS
        if (now - lastSave > 30_000) {
            lastSave = now
            saveAuth()
        }
        return d
    }

    @Synchronized
    fun logout(token: String) {
        sessions.remove(sha(token))
        saveAuth()
    }

    @Synchronized
    fun removeDevice(id: String) {
        devices.remove(id)
        val it = sessions.entries.iterator()
        while (it.hasNext()) {
            if (it.next().value.deviceId == id) it.remove()
        }
        saveAuth()
    }

    @Synchronized
    fun deviceList(): List<Device> = devices.values.toList()

    @Synchronized
    fun setWrite(id: String, v: Boolean) {
        devices[id]?.canWrite = v
        saveAuth()
    }

    @Synchronized
    fun revokeAllExcept(id: String) {
        val ids = devices.keys.filter { it != id }
        for (x in ids) removeDevice(x)
    }

    private fun saveAuth() {
        val da = JSONArray()
        for (d in devices.values) {
            da.put(
                JSONObject()
                    .put("id", d.id).put("name", d.name).put("created", d.created)
                    .put("lastSeen", d.lastSeen).put("ip", d.ip).put("canWrite", d.canWrite)
                    .put("admin", d.admin).put("ua", d.ua)
            )
        }
        val so = JSONObject()
        for ((k, v) in sessions) {
            so.put(k, JSONObject().put("d", v.deviceId).put("e", v.expires))
        }
        sp.edit().putString("devices", da.toString()).putString("sessions", so.toString()).apply()
    }

    private fun loadAuth() {
        try {
            val da = JSONArray(sp.getString("devices", "[]"))
            for (i in 0 until da.length()) {
                val o = da.getJSONObject(i)
                val id = o.getString("id")
                devices[id] = Device(
                    id, o.getString("name"), o.getLong("created"), o.getLong("lastSeen"),
                    o.optString("ip", ""), o.optBoolean("canWrite", true),
                    o.optBoolean("admin", false), o.optString("ua", "")
                )
            }
            val so = JSONObject(sp.getString("sessions", "{}"))
            val keys = so.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val o = so.getJSONObject(k)
                sessions[k] = Sess(o.getString("d"), o.getLong("e"))
            }
        } catch (e: Exception) {
            devices.clear()
            sessions.clear()
        }
    }
}
