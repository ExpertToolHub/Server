package com.qunverio.cloud

import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Byte counters, speed and CPU sampling (ticked once per second). */
object Stats {
    val bytesIn = AtomicLong()
    val bytesOut = AtomicLong()

    @Volatile var speedIn = 0L
    @Volatile var speedOut = 0L
    @Volatile var cpu = 0.0
    @Volatile var startedAt = System.currentTimeMillis()

    private var lastIn = 0L
    private var lastOut = 0L
    private var lastCpu = 0L
    private var lastWall = 0L

    fun reset() {
        startedAt = System.currentTimeMillis()
        lastIn = bytesIn.get()
        lastOut = bytesOut.get()
        lastCpu = android.os.Process.getElapsedCpuTime()
        lastWall = SystemClock.elapsedRealtime()
        speedIn = 0
        speedOut = 0
        cpu = 0.0
    }

    fun tick() {
        val now = SystemClock.elapsedRealtime()
        val dt = (now - lastWall).coerceAtLeast(1)
        val i = bytesIn.get()
        val o = bytesOut.get()
        speedIn = (i - lastIn) * 1000 / dt
        speedOut = (o - lastOut) * 1000 / dt
        val cpuMs = android.os.Process.getElapsedCpuTime()
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val pct = (cpuMs - lastCpu).toDouble() / dt / cores * 100.0
        cpu = if (pct.isNaN() || pct.isInfinite()) 0.0 else pct.coerceIn(0.0, 100.0)
        lastIn = i
        lastOut = o
        lastCpu = cpuMs
        lastWall = now

        // drop stale upload entries (client vanished)
        val t = System.currentTimeMillis()
        Transfers.map.entries.removeIf { it.value.kind == "up" && t - it.value.touched > 30_000 }
    }
}

/** Limits simultaneous heavy connections (uploads, downloads, streams). */
object Gate {
    const val MAX = 24
    val active = AtomicInteger(0)
}

class Transfer(
    val id: String,
    val name: String,
    val kind: String, // "up", "down" or "stream"
    val total: Long,
    val device: String
) {
    val done = AtomicLong()
    @Volatile var touched = System.currentTimeMillis()
    val started = System.currentTimeMillis()
}

object Transfers {
    val map = ConcurrentHashMap<String, Transfer>()

    fun json(): JSONArray {
        val a = JSONArray()
        val now = System.currentTimeMillis()
        for (t in map.values) {
            a.put(
                JSONObject()
                    .put("id", t.id).put("name", t.name).put("kind", t.kind)
                    .put("total", t.total).put("done", t.done.get())
                    .put("device", t.device).put("age", now - t.started)
            )
        }
        return a
    }
}

object Activity {
    private val items = ArrayList<JSONObject>()

    @Synchronized
    fun log(device: String, action: String, detail: String) {
        items.add(
            JSONObject().put("t", System.currentTimeMillis()).put("device", device)
                .put("action", action).put("detail", detail)
        )
        while (items.size > 200) items.removeAt(0)
    }

    @Synchronized
    fun recent(n: Int): JSONArray {
        val a = JSONArray()
        var i = items.size - 1
        var c = 0
        while (i >= 0 && c < n) {
            a.put(items[i])
            i--
            c++
        }
        return a
    }
}
