package com.qunverio.cloud

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** Foreground service: keeps the server alive while the app is in the background. */
class ServerService : Service() {

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Store.init(this)
            Store.wantRunning = false
            QServer.stop()
            release()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        Store.init(this)
        startForeground(NOTIF_ID, notification())
        if (!QServer.running) {
            if (!QServer.start(this)) {
                Store.wantRunning = false
                release()
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        Store.wantRunning = true
        acquire()
        return START_STICKY
    }

    private fun acquire() {
        try {
            if (wake == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "qunverio:server").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
            if (wifi == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "qunverio:wifi").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } catch (e: Exception) {
            // locks are best effort
        }
    }

    private fun release() {
        try {
            wake?.let { if (it.isHeld) it.release() }
            wifi?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            // ignore
        }
        wake = null
        wifi = null
    }

    private fun notification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Qunverio Server", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ServerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val url = Net.primaryUrl(Store.port) ?: "Network nahi mila"
        @Suppress("DEPRECATION")
        val b: Notification.Builder =
            if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return b.setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Qunverio Turbo chal raha hai")
            .setContentText(url)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }

    override fun onDestroy() {
        QServer.stop()
        release()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "qc_server"
        const val NOTIF_ID = 1
        const val ACTION_STOP = "com.qunverio.cloud.STOP"

        fun start(c: Context) {
            val i = Intent(c, ServerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        fun stop(c: Context) {
            c.startService(Intent(c, ServerService::class.java).setAction(ACTION_STOP))
        }
    }
}
