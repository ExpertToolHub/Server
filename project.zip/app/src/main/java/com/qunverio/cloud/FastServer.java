package com.qunverio.cloud;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Small, fast HTTP server only for bulk bytes: downloads/streams (with Range), chunked uploads
 * and a speed test. It talks to the socket directly with big buffers, so it is much faster than
 * pushing file data through the general web framework.
 *
 * Access is controlled with short-lived random tickets that the logged-in dashboard asks for
 * from the main server. No ticket, no data.
 */
public final class FastServer {

    public interface Handle {
        void progress(long n);

        void end();
    }

    public interface Host {
        File resolve(String deviceId, String rel);

        File root();

        String mime(String name);

        boolean inlineSafe(String mime);

        String cleanName(String n);

        String uploadId(String deviceId, String dirRel, String name, long total);

        File unique(File dir, String name);

        boolean deviceOk(String deviceId, boolean write);

        boolean shareOk(String token);

        void addIn(long n);

        void addOut(long n);

        Handle begin(String name, String kind, long total, String device);

        void uploadProgress(String id, String name, long total, long done, String device);

        void uploadDone(String id);

        void log(String device, String action, String detail);

        String tmpDirName();
    }

    private static final class Ticket {
        final String path;
        final String deviceId;
        final String deviceName;
        final String share;
        final boolean write;
        final long expires;

        Ticket(String path, String deviceId, String deviceName, String share, boolean write, long expires) {
            this.path = path;
            this.deviceId = deviceId;
            this.deviceName = deviceName;
            this.share = share;
            this.write = write;
            this.expires = expires;
        }
    }

    private static final class Conn {
        final SocketChannel ch;
        volatile long last = System.currentTimeMillis();
        byte[] buf = new byte[32 * 1024];
        int start = 0;
        int len = 0;
        ByteBuffer dbuf;

        Conn(SocketChannel ch) {
            this.ch = ch;
        }
    }

    private static final class Req {
        String method;
        String path;
        String query = "";
        final Map<String, String> headers = new HashMap<>();
    }

    private static final int MAX_CONN = 48;
    private static final long MAX_CHUNK = 64L * 1024 * 1024;
    private static final int BUF = 1024 * 1024;
    private static final long IDLE_MS = 120_000;

    private final Host host;
    private final SecureRandom rnd = new SecureRandom();
    private final ConcurrentHashMap<String, Ticket> tickets = new ConcurrentHashMap<>();
    private final Set<Conn> conns = ConcurrentHashMap.newKeySet();
    private volatile boolean running = false;
    private ServerSocketChannel server;
    private ExecutorService pool;

    public FastServer(Host host) {
        this.host = host;
    }

    // ------------------------------------------------------------------ lifecycle

    public synchronized void start(int port) throws IOException {
        if (running) return;
        ServerSocketChannel s = ServerSocketChannel.open();
        try {
            s.setOption(StandardSocketOptions.SO_REUSEADDR, true);
            s.bind(new InetSocketAddress(port), 128);
        } catch (IOException e) {
            s.close();
            throw e;
        }
        server = s;
        running = true;
        pool = Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "fast-conn");
            t.setDaemon(true);
            return t;
        });
        Thread acc = new Thread(this::acceptLoop, "fast-accept");
        acc.setDaemon(true);
        acc.start();
        Thread wd = new Thread(this::watchdog, "fast-watchdog");
        wd.setDaemon(true);
        wd.start();
    }

    public synchronized void stop() {
        running = false;
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }
        for (Conn c : conns) closeQuietly(c);
        conns.clear();
        tickets.clear();
        if (pool != null) pool.shutdownNow();
    }

    public String issue(String path, String deviceId, String deviceName, boolean write, String share, long ttlMs) {
        byte[] b = new byte[16];
        rnd.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        if (tickets.size() > 20000) purge();
        String tok = sb.toString();
        tickets.put(tok, new Ticket(path == null ? "" : path, deviceId, deviceName, share, write,
                System.currentTimeMillis() + ttlMs));
        return tok;
    }

    private void purge() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<String, Ticket>> it = tickets.entrySet().iterator();
        while (it.hasNext()) {
            if (it.next().getValue().expires < now) it.remove();
        }
    }

    private void acceptLoop() {
        while (running) {
            try {
                SocketChannel ch = server.accept();
                if (conns.size() >= MAX_CONN) {
                    ch.close();
                    continue;
                }
                Conn c = new Conn(ch);
                conns.add(c);
                pool.execute(() -> serve(c));
            } catch (IOException e) {
                if (!running) break;
            } catch (RuntimeException e) {
                if (!running) break;
            }
        }
    }

    private void watchdog() {
        while (running) {
            try {
                Thread.sleep(15_000);
            } catch (InterruptedException e) {
                return;
            }
            long now = System.currentTimeMillis();
            for (Conn c : conns) {
                if (now - c.last > IDLE_MS) closeQuietly(c);
            }
            purge();
        }
    }

    private void closeQuietly(Conn c) {
        try {
            c.ch.close();
        } catch (IOException ignored) {
        }
        conns.remove(c);
    }

    // ------------------------------------------------------------------ connection loop

    private void serve(Conn c) {
        try {
            try {
                c.ch.setOption(StandardSocketOptions.TCP_NODELAY, true);
                c.ch.setOption(StandardSocketOptions.SO_SNDBUF, BUF);
                c.ch.setOption(StandardSocketOptions.SO_RCVBUF, BUF);
            } catch (Exception ignored) {
            }
            while (running) {
                Req r = readRequest(c);
                if (r == null) break;
                boolean keep = dispatch(c, r);
                if (!keep) break;
                if ("close".equalsIgnoreCase(r.headers.get("connection"))) break;
            }
        } catch (Exception e) {
            // client went away or a bad request: just drop the connection
        } finally {
            closeQuietly(c);
        }
    }

    private static int headerEnd(byte[] b, int from, int to) {
        for (int i = from; i + 3 < to; i++) {
            if (b[i] == '\r' && b[i + 1] == '\n' && b[i + 2] == '\r' && b[i + 3] == '\n') return i;
        }
        return -1;
    }

    private Req readRequest(Conn c) throws IOException {
        while (true) {
            int end = headerEnd(c.buf, c.start, c.len);
            if (end >= 0) {
                String head = new String(c.buf, c.start, end - c.start, StandardCharsets.ISO_8859_1);
                c.start = end + 4;
                if (c.start == c.len) {
                    c.start = 0;
                    c.len = 0;
                }
                return parse(head);
            }
            if (c.start > 0) {
                System.arraycopy(c.buf, c.start, c.buf, 0, c.len - c.start);
                c.len -= c.start;
                c.start = 0;
            }
            if (c.len >= c.buf.length) return null;
            int n = c.ch.read(ByteBuffer.wrap(c.buf, c.len, c.buf.length - c.len));
            if (n < 0) return null;
            c.len += n;
            c.last = System.currentTimeMillis();
        }
    }

    private Req parse(String head) {
        String[] lines = head.split("\r\n");
        if (lines.length == 0) return null;
        String[] first = lines[0].split(" ");
        if (first.length < 2) return null;
        Req r = new Req();
        r.method = first[0].toUpperCase();
        String target = first[1];
        int q = target.indexOf('?');
        if (q >= 0) {
            r.path = target.substring(0, q);
            r.query = target.substring(q + 1);
        } else {
            r.path = target;
        }
        for (int i = 1; i < lines.length; i++) {
            int k = lines[i].indexOf(':');
            if (k > 0) r.headers.put(lines[i].substring(0, k).trim().toLowerCase(), lines[i].substring(k + 1).trim());
        }
        return r;
    }

    private static Map<String, String> params(String q) {
        Map<String, String> m = new HashMap<>();
        if (q == null || q.isEmpty()) return m;
        for (String p : q.split("&")) {
            int i = p.indexOf('=');
            try {
                if (i < 0) m.put(URLDecoder.decode(p, "UTF-8"), "");
                else m.put(URLDecoder.decode(p.substring(0, i), "UTF-8"), URLDecoder.decode(p.substring(i + 1), "UTF-8"));
            } catch (Exception ignored) {
            }
        }
        return m;
    }

    // ------------------------------------------------------------------ responses

    private static String cors() {
        return "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, HEAD, OPTIONS\r\n"
                + "Access-Control-Allow-Headers: *\r\nAccess-Control-Max-Age: 86400\r\n";
    }

    private void writeAll(Conn c, ByteBuffer bb) throws IOException {
        while (bb.hasRemaining()) {
            c.ch.write(bb);
            c.last = System.currentTimeMillis();
        }
    }

    private boolean sendBytes(Conn c, int code, String reason, String type, byte[] body, boolean keep) throws IOException {
        String h = "HTTP/1.1 " + code + " " + reason + "\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + cors()
                + "Cache-Control: no-store\r\n"
                + "Connection: " + (keep ? "keep-alive" : "close") + "\r\n\r\n";
        writeAll(c, ByteBuffer.wrap(h.getBytes(StandardCharsets.ISO_8859_1)));
        if (body.length > 0) writeAll(c, ByteBuffer.wrap(body));
        return keep;
    }

    private boolean sendText(Conn c, int code, String reason, String text, boolean keep) throws IOException {
        return sendBytes(c, code, reason, "text/plain; charset=utf-8", text.getBytes(StandardCharsets.UTF_8), keep);
    }

    private boolean sendJson(Conn c, int code, String reason, String json, boolean keep) throws IOException {
        return sendBytes(c, code, reason, "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8), keep);
    }

    private static String jesc(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '"' || ch == '\\') sb.append('\\').append(ch);
            else if (ch < 0x20) sb.append(' ');
            else sb.append(ch);
        }
        return sb.toString();
    }

    private ByteBuffer dbuf(Conn c) {
        if (c.dbuf == null) c.dbuf = ByteBuffer.allocateDirect(BUF);
        return c.dbuf;
    }

    // ------------------------------------------------------------------ routing

    private Ticket ticket(String token, boolean write) {
        Ticket t = tickets.get(token);
        if (t == null) return null;
        if (System.currentTimeMillis() > t.expires) {
            tickets.remove(token);
            return null;
        }
        if (t.share != null) {
            if (write || !host.shareOk(t.share)) return null;
        } else if (!host.deviceOk(t.deviceId, write)) {
            return null;
        }
        if (write && !t.write) return null;
        return t;
    }

    private boolean dispatch(Conn c, Req r) throws IOException {
        if ("OPTIONS".equals(r.method)) {
            String h = "HTTP/1.1 204 No Content\r\n" + cors() + "Content-Length: 0\r\nConnection: keep-alive\r\n\r\n";
            writeAll(c, ByteBuffer.wrap(h.getBytes(StandardCharsets.ISO_8859_1)));
            return true;
        }
        String[] seg = r.path.split("/");
        if (seg.length < 3) return sendText(c, 404, "Not Found", "Not found", true);
        String kind = seg[1];
        String token = seg[2];
        Map<String, String> q = params(r.query);
        boolean get = "GET".equals(r.method) || "HEAD".equals(r.method);
        switch (kind) {
            case "f":
                if (!get) return sendText(c, 405, "Method Not Allowed", "GET only", true);
                return download(c, r, token, q);
            case "us":
                if (!get) return sendText(c, 405, "Method Not Allowed", "GET only", true);
                return uploadStatus(c, token, q);
            case "u":
                if (!"POST".equals(r.method) && !"PUT".equals(r.method)) {
                    return sendText(c, 405, "Method Not Allowed", "POST only", false);
                }
                return upload(c, r, token, q);
            case "z":
                if (!get) return sendText(c, 405, "Method Not Allowed", "GET only", true);
                return zero(c, token, q);
            default:
                return sendText(c, 404, "Not Found", "Not found", true);
        }
    }

    // ------------------------------------------------------------------ download / stream

    private boolean download(Conn c, Req r, String token, Map<String, String> q) throws IOException {
        Ticket t = ticket(token, false);
        if (t == null) return sendText(c, 404, "Not Found", "Link expire ho gaya", true);
        File f = host.resolve(t.deviceId, t.path);
        if (t.path.isEmpty() || f == null || !f.isFile()) return sendText(c, 404, "Not Found", "File nahi mili", true);

        long len = f.length();
        long start = 0;
        long end = len - 1;
        boolean partial = false;
        String rh = r.headers.get("range");
        if (rh != null && rh.startsWith("bytes=") && rh.indexOf(',') < 0) {
            String spec = rh.substring(6).trim();
            int dash = spec.indexOf('-');
            if (dash >= 0) {
                String a = spec.substring(0, dash).trim();
                String b = spec.substring(dash + 1).trim();
                try {
                    if (a.isEmpty()) {
                        long n = Long.parseLong(b);
                        if (n <= 0) throw new NumberFormatException();
                        start = Math.max(0, len - n);
                    } else {
                        start = Long.parseLong(a);
                        if (!b.isEmpty()) end = Math.min(Long.parseLong(b), len - 1);
                    }
                    partial = true;
                } catch (NumberFormatException e) {
                    partial = false;
                    start = 0;
                    end = len - 1;
                }
            }
        }
        if (partial && (start >= len || start > end)) {
            String h = "HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */" + len + "\r\n"
                    + cors() + "Content-Length: 0\r\nConnection: keep-alive\r\n\r\n";
            writeAll(c, ByteBuffer.wrap(h.getBytes(StandardCharsets.ISO_8859_1)));
            return true;
        }
        long count = len == 0 ? 0 : end - start + 1;
        String mime = host.mime(f.getName());
        boolean forceDl = "1".equals(q.get("dl"));
        boolean inline = !forceDl && host.inlineSafe(mime);
        String enc;
        try {
            enc = java.net.URLEncoder.encode(f.getName(), "UTF-8").replace("+", "%20");
        } catch (Exception e) {
            enc = "file";
        }
        StringBuilder h = new StringBuilder();
        h.append("HTTP/1.1 ").append(partial ? "206 Partial Content" : "200 OK").append("\r\n");
        h.append("Content-Type: ").append(mime).append("\r\n");
        h.append("Content-Length: ").append(count).append("\r\n");
        if (partial) h.append("Content-Range: bytes ").append(start).append('-').append(end).append('/').append(len).append("\r\n");
        h.append("Accept-Ranges: bytes\r\n");
        h.append("Content-Disposition: ").append(inline ? "inline" : "attachment").append("; filename*=UTF-8''").append(enc).append("\r\n");
        h.append("X-Content-Type-Options: nosniff\r\n");
        h.append("Content-Security-Policy: sandbox; default-src 'none'; media-src 'self'; img-src 'self'\r\n");
        h.append("Cache-Control: private, max-age=0\r\n");
        h.append(cors());
        h.append("Connection: keep-alive\r\n\r\n");
        writeAll(c, ByteBuffer.wrap(h.toString().getBytes(StandardCharsets.ISO_8859_1)));
        if ("HEAD".equals(r.method) || count == 0) return true;

        if (start == 0) host.log(t.deviceName, inline ? "view" : "download", f.getName());
        Handle handle = null;
        if (count > 2L * 1024 * 1024 && (start == 0 || !inline)) {
            handle = host.begin(f.getName(), inline ? "stream" : "down", count, t.deviceName);
        }
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            FileChannel fc = raf.getChannel();
            long pos = start;
            long left = count;
            // zero-copy: the kernel moves bytes from the file to the socket (sendfile), no copy through Java memory
            while (left > 0) {
                long n = fc.transferTo(pos, Math.min(left, 8L * 1024 * 1024), c.ch);
                if (n <= 0) {
                    if (pos >= len) return false;
                    Thread.yield();
                    n = fc.transferTo(pos, Math.min(left, 8L * 1024 * 1024), c.ch);
                    if (n <= 0) return false;
                }
                pos += n;
                left -= n;
                host.addOut(n);
                if (handle != null) handle.progress(n);
            }
        } finally {
            if (handle != null) handle.end();
        }
        return true;
    }

    // ------------------------------------------------------------------ upload

    private boolean uploadStatus(Conn c, String token, Map<String, String> q) throws IOException {
        Ticket t = ticket(token, true);
        if (t == null) return sendJson(c, 403, "Forbidden", "{\"error\":\"ticket\"}", true);
        String name = host.cleanName(q.getOrDefault("name", ""));
        long total = parseLong(q.get("total"), -1);
        if (name == null || total < 0) return sendJson(c, 400, "Bad Request", "{\"error\":\"bad request\"}", true);
        String id = host.uploadId(t.deviceId, q.getOrDefault("dir", ""), name, total);
        File tmp = new File(new File(host.root(), host.tmpDirName()), id + ".part");
        return sendJson(c, 200, "OK", "{\"offset\":" + (tmp.isFile() ? tmp.length() : 0) + "}", true);
    }

    private static long parseLong(String s, long d) {
        if (s == null) return d;
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return d;
        }
    }

    private boolean upload(Conn c, Req r, String token, Map<String, String> q) throws IOException {
        // Any early error closes the connection, because an unread body would confuse the next request.
        if ("100-continue".equalsIgnoreCase(r.headers.getOrDefault("expect", ""))) {
            writeAll(c, ByteBuffer.wrap("HTTP/1.1 100 Continue\r\n\r\n".getBytes(StandardCharsets.ISO_8859_1)));
        }
        Ticket t = ticket(token, true);
        if (t == null) return sendJson(c, 403, "Forbidden", "{\"error\":\"Login ya ticket expire\"}", false);
        String dirRel = q.getOrDefault("dir", "");
        File dir = host.resolve(t.deviceId, dirRel);
        String name = host.cleanName(q.getOrDefault("name", ""));
        long total = parseLong(q.get("total"), -1);
        long offset = parseLong(q.get("offset"), -1);
        long declared = parseLong(r.headers.get("content-length"), -1);
        if (dir == null || !dir.isDirectory() || name == null || total < 0 || offset < 0 || offset > total) {
            return sendJson(c, 400, "Bad Request", "{\"error\":\"Upload request sahi nahi hai\"}", false);
        }
        if (declared < 0 || declared > MAX_CHUNK || offset + declared > total) {
            return sendJson(c, 400, "Bad Request", "{\"error\":\"Chunk size sahi nahi hai\"}", false);
        }
        File root = host.root();
        if (root.getUsableSpace() < declared + 100L * 1024 * 1024) {
            return sendJson(c, 507, "Insufficient Storage", "{\"error\":\"Phone me jagah kam hai\"}", false);
        }
        File tmpDir = new File(root, host.tmpDirName());
        tmpDir.mkdirs();
        String id = host.uploadId(t.deviceId, dirRel, name, total);
        File tmp = new File(tmpDir, id + ".part");
        long have = tmp.isFile() ? tmp.length() : 0;
        if (offset != have) {
            return sendJson(c, 409, "Conflict", "{\"error\":\"offset\",\"offset\":" + have + "}", false);
        }

        long got = 0;
        try (FileChannel fc = FileChannel.open(tmp.toPath(), StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {
            fc.position(offset);
            int pre = (int) Math.min(c.len - c.start, declared);
            if (pre > 0) {
                ByteBuffer pb = ByteBuffer.wrap(c.buf, c.start, pre);
                while (pb.hasRemaining()) fc.write(pb);
                c.start += pre;
                if (c.start == c.len) {
                    c.start = 0;
                    c.len = 0;
                }
                got += pre;
                host.addIn(pre);
            }
            ByteBuffer bb = dbuf(c);
            while (got < declared) {
                bb.clear();
                long left = declared - got;
                if (left < bb.capacity()) bb.limit((int) left);
                int n = c.ch.read(bb);
                if (n < 0) break;
                c.last = System.currentTimeMillis();
                bb.flip();
                while (bb.hasRemaining()) fc.write(bb);
                got += n;
                host.addIn(n);
                host.uploadProgress(id, name, total, offset + got, t.deviceName);
            }
        }
        if (got != declared) return false;

        long newSize = offset + got;
        if (newSize == total) {
            File fin = host.unique(dir, name);
            if (!tmp.renameTo(fin)) {
                Files.copy(tmp.toPath(), fin.toPath());
                tmp.delete();
            }
            host.uploadDone(id);
            host.log(t.deviceName, "upload", fin.getName());
            return sendJson(c, 200, "OK",
                    "{\"done\":true,\"offset\":" + newSize + ",\"name\":\"" + jesc(fin.getName()) + "\"}", true);
        }
        return sendJson(c, 200, "OK", "{\"done\":false,\"offset\":" + newSize + "}", true);
    }

    // ------------------------------------------------------------------ speed test

    private boolean zero(Conn c, String token, Map<String, String> q) throws IOException {
        Ticket t = ticket(token, false);
        if (t == null) return sendText(c, 404, "Not Found", "ticket", true);
        long mb = Math.max(1, Math.min(1000, parseLong(q.get("mb"), 100)));
        long total = mb * 1024 * 1024;
        String h = "HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: " + total + "\r\n"
                + cors() + "Cache-Control: no-store\r\nConnection: keep-alive\r\n\r\n";
        writeAll(c, ByteBuffer.wrap(h.getBytes(StandardCharsets.ISO_8859_1)));
        ByteBuffer bb = dbuf(c);
        long left = total;
        while (left > 0) {
            bb.clear();
            if (left < bb.capacity()) bb.limit((int) left);
            int n = bb.remaining();
            writeAll(c, bb);
            left -= n;
        }
        return true;
    }
}
