package com.qunverio.cloud

import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

/** Temporary public links for one file or folder. The token is the only secret. */
object Shares {
    class Share(
        val token: String,
        val path: String,
        val name: String,
        val dir: Boolean,
        val created: Long,
        val expires: Long,
        val by: String
    )

    private val map = LinkedHashMap<String, Share>()
    private val rnd = SecureRandom()
    private var loaded = false

    @Synchronized
    private fun load() {
        if (loaded) return
        loaded = true
        try {
            val a = JSONArray(Store.getString("shares", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val s = Share(
                    o.getString("token"), o.getString("path"), o.getString("name"),
                    o.getBoolean("dir"), o.getLong("created"), o.getLong("expires"), o.optString("by", "")
                )
                map[s.token] = s
            }
        } catch (e: Exception) {
            map.clear()
        }
    }

    private fun save() {
        val a = JSONArray()
        for (s in map.values) {
            a.put(
                JSONObject().put("token", s.token).put("path", s.path).put("name", s.name)
                    .put("dir", s.dir).put("created", s.created).put("expires", s.expires).put("by", s.by)
            )
        }
        Store.putString("shares", a.toString())
    }

    private fun prune() {
        val now = System.currentTimeMillis()
        val it = map.entries.iterator()
        while (it.hasNext()) {
            if (it.next().value.expires < now) it.remove()
        }
    }

    @Synchronized
    fun create(path: String, name: String, dir: Boolean, hours: Int, by: String): Share {
        load()
        prune()
        val b = ByteArray(12)
        rnd.nextBytes(b)
        val token = b.joinToString("") { "%02x".format(it) }
        val now = System.currentTimeMillis()
        val s = Share(token, path, name, dir, now, now + hours * 3600_000L, by)
        map[token] = s
        save()
        return s
    }

    @Synchronized
    fun get(token: String): Share? {
        load()
        val s = map[token] ?: return null
        if (System.currentTimeMillis() > s.expires) {
            map.remove(token)
            save()
            return null
        }
        return s
    }

    @Synchronized
    fun list(): List<Share> {
        load()
        prune()
        return map.values.toList()
    }

    @Synchronized
    fun revoke(token: String) {
        load()
        map.remove(token)
        save()
    }
}
