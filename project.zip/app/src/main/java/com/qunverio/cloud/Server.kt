package com.qunverio.cloud

import android.content.Context
import io.ktor.server.cio.CIO
import io.ktor.server.engine.ApplicationEngine
import io.ktor.server.engine.embeddedServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.ServerSocket

/** Starts and stops the embedded HTTP server. */
object QServer {
    @Volatile var running = false
    @Volatile var lastError: String? = null
    lateinit var ctx: Context

    private var engine: ApplicationEngine? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    @Synchronized
    fun start(c: Context): Boolean {
        if (running) return true
        ctx = c.applicationContext
        Store.init(ctx)
        val port = Store.port
        try {
            ServerSocket(port).close()
        } catch (e: Exception) {
            lastError = "Port $port busy hai ya use nahi ho sakta"
            return false
        }
        return try {
            val e = embeddedServer(
                CIO,
                port = port,
                host = "0.0.0.0",
                configure = { connectionIdleTimeoutSeconds = 120 }
            ) { qcModule() }
            e.start(wait = false)
            engine = e
            running = true
            lastError = null
            Stats.reset()
            Fast.start(port + 1)
            try {
                FileOps.cleanTmp()
            } catch (x: Exception) {
                // not critical
            }
            job?.cancel()
            job = scope.launch {
                var n = 0
                while (true) {
                    Stats.tick()
                    if (n % 30 == 0) launch(Dispatchers.IO) { FileOps.refreshUsed() }
                    n++
                    delay(1000)
                }
            }
            true
        } catch (t: Throwable) {
            lastError = t.message ?: t.javaClass.simpleName
            running = false
            false
        }
    }

    @Synchronized
    fun stop() {
        running = false
        job?.cancel()
        job = null
        try {
            engine?.stop(200, 1000)
        } catch (e: Exception) {
            // ignore
        }
        engine = null
        Fast.stop()
        Transfers.map.clear()
        Gate.active.set(0)
    }
}
