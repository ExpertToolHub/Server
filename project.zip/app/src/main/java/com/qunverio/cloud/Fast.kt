package com.qunverio.cloud

import java.io.File

/** Glue between the app and FastServer (the fast socket server for bulk bytes). */
object Fast {
    @Volatile var server: FastServer? = null
    @Volatile var port = 0

    @Synchronized
    fun start(p: Int) {
        stop()
        try {
            val s = FastServer(FastHost)
            s.start(p)
            server = s
            port = p
        } catch (e: Throwable) {
            server = null
            port = 0
        }
    }

    @Synchronized
    fun stop() {
        try {
            server?.stop()
        } catch (e: Throwable) {
            // ignore
        }
        server = null
        port = 0
    }
}

object FastHost : FastServer.Host {
    override fun resolve(deviceId: String?, rel: String?): File? {
        val base = FileOps.baseFor(deviceId ?: "") ?: return null
        return FileOps.resolve(rel, base)
    }

    override fun root(): File = FileOps.root()

    override fun mime(name: String): String = FileOps.mime(name)

    override fun inlineSafe(mime: String): Boolean = FileOps.inlineSafe(mime)

    override fun cleanName(n: String): String? = FileOps.cleanName(n)

    override fun uploadId(deviceId: String, dirRel: String, name: String, total: Long): String =
        FileOps.uploadId(deviceId, dirRel, name, total)

    override fun unique(dir: File, name: String): File = FileOps.unique(dir, name)

    override fun deviceOk(deviceId: String, write: Boolean): Boolean {
        val d = Store.deviceList().firstOrNull { it.id == deviceId } ?: return false
        if (d.admin) return true
        if (!Store.guestActive()) return false
        return !write || Store.canUpload(d)
    }

    override fun shareOk(token: String): Boolean = Shares.get(token) != null

    override fun addIn(n: Long) {
        Stats.bytesIn.addAndGet(n)
    }

    override fun addOut(n: Long) {
        Stats.bytesOut.addAndGet(n)
    }

    override fun begin(name: String, kind: String, total: Long, device: String): FastServer.Handle {
        val id = "f-" + java.util.UUID.randomUUID().toString().take(8)
        val t = Transfer(id, name, kind, total, device)
        Transfers.map[id] = t
        return object : FastServer.Handle {
            override fun progress(n: Long) {
                t.done.addAndGet(n)
                t.touched = System.currentTimeMillis()
            }

            override fun end() {
                Transfers.map.remove(id)
            }
        }
    }

    override fun uploadProgress(id: String, name: String, total: Long, done: Long, device: String) {
        val t = Transfers.map.getOrPut(id) { Transfer(id, name, "up", total, device) }
        t.done.set(done)
        t.touched = System.currentTimeMillis()
    }

    override fun uploadDone(id: String) {
        Transfers.map.remove(id)
    }

    override fun log(device: String, action: String, detail: String) {
        Activity.log(device, action, detail)
    }

    override fun tmpDirName(): String = FileOps.TMP
}
