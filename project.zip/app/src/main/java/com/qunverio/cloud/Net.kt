package com.qunverio.cloud

import java.net.Inet4Address
import java.net.NetworkInterface

object Net {
    class Addr(val iface: String, val ip: String, val kind: String)

    /** All usable IPv4 addresses of this phone (Wi-Fi, hotspot, Tailscale, ethernet). */
    fun addresses(): List<Addr> {
        val out = ArrayList<Addr>()
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return out
            for (ni in all.toList()) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("v4-") ||
                    n.startsWith("dummy") || n.startsWith("p2p")
                ) continue
                for (ia in ni.inetAddresses.toList()) {
                    if (ia !is Inet4Address || ia.isLoopbackAddress) continue
                    val ip = ia.hostAddress ?: continue
                    out.add(Addr(n, ip, kind(n, ip)))
                }
            }
        } catch (e: Exception) {
            // ignore, return what we have
        }
        return out
    }

    private fun kind(n: String, ip: String): String {
        val p = ip.split('.')
        val second = p.getOrNull(1)?.toIntOrNull() ?: 0
        return when {
            p[0] == "100" && second in 64..127 -> "tailscale"
            n.startsWith("tun") || n.startsWith("tailscale") -> "vpn"
            n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap") || n == "wlan1" -> "hotspot"
            n.startsWith("wlan") -> "wifi"
            n.startsWith("eth") -> "ethernet"
            else -> "other"
        }
    }

    /** Best address to show first: Wi-Fi, then hotspot, then others. */
    fun primaryUrl(port: Int): String? {
        val a = addresses()
        val best = a.firstOrNull { it.kind == "wifi" } ?: a.firstOrNull { it.kind == "hotspot" }
            ?: a.firstOrNull { it.kind == "ethernet" } ?: a.firstOrNull()
        return best?.let { "http://${it.ip}:$port" }
    }
}
