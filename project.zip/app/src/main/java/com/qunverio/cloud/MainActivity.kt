package com.qunverio.cloud

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Simple control screen: password, start/stop, addresses, pairing code, permissions. */
class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var urls: TextView
    private lateinit var pairView: TextView
    private lateinit var toggle: Button
    private lateinit var storageBtn: Button
    private lateinit var pwBtn: Button
    private lateinit var guestInfo: TextView
    private lateinit var guestOnBtn: Button
    private lateinit var guestUpBtn: Button
    private lateinit var guestDelBtn: Button

    private val bg = Color.parseColor("#0E1320")
    private val card = Color.parseColor("#182033")
    private val accent = Color.parseColor("#4F7CFF")
    private val text = Color.parseColor("#E8ECF6")
    private val muted = Color.parseColor("#9AA6C0")

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        // Android may have killed the service: bring it back if the user wanted it running.
        if (Store.wantRunning && !QServer.running && Store.hasPassword) ServerService.start(this)
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(s: String, size: Float, color: Int = text, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun btn(s: String, primary: Boolean, click: () -> Unit): Button =
        Button(this).apply {
            this.text = s
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(if (primary) accent else Color.parseColor("#2A3550"))
            setOnClickListener { click() }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
        }

    private fun box(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(card)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(12)
        layoutParams = lp
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        root.addView(tv("Qunverio Turbo", 26f, text, true))
        root.addView(tv("Aapka apna personal cloud server", 14f, muted))

        // status card
        val c1 = box()
        status = tv("", 18f, text, true)
        urls = tv("", 15f, text)
        urls.setPadding(0, dp(8), 0, 0)
        urls.setTextIsSelectable(true)
        c1.addView(status)
        c1.addView(urls)
        toggle = btn("Start Server", true) { onToggle() }
        c1.addView(toggle)
        c1.addView(btn("Link copy karo", false) { copyUrl() })
        root.addView(c1)

        // password card
        val c2 = box()
        c2.addView(tv("Password", 16f, text, true))
        c2.addView(tv("Dashboard me login karne ke liye (kam se kam 6 character).", 13f, muted))
        pwBtn = btn("Password set karo", false) { askPassword() }
        c2.addView(pwBtn)
        root.addView(c2)

        // pairing card
        val c3 = box()
        c3.addView(tv("Naya device pair karo", 16f, text, true))
        c3.addView(tv("Code 5 minute chalta hai. Code se jude device guest ban jaate hain (sirf Guest folder, permissions upar wale card se).", 13f, muted))
        pairView = tv("------", 32f, accent, true)
        pairView.gravity = Gravity.CENTER
        pairView.setPadding(0, dp(12), 0, dp(4))
        c3.addView(pairView)
        c3.addView(btn("Naya code banao", false) {
            pairView.text = Pairing.newCode()
        })
        root.addView(c3)

        // guest card
        val cg = box()
        cg.addView(tv("👥 Guest access (sirf ek folder)", 16f, text, true))
        cg.addView(tv("Guest ko sirf neeche wala folder dikhega: download, upload aur dekhna. Baaki phone nahi.", 13f, muted))
        guestInfo = tv("", 14f, text)
        guestInfo.setPadding(0, dp(8), 0, dp(4))
        cg.addView(guestInfo)
        guestOnBtn = btn("", true) { Store.guestEnabled = !Store.guestEnabled; if (Store.guestEnabled) Store.guestUntil = 0L; refresh() }
        cg.addView(guestOnBtn)
        cg.addView(btn("Sirf 1 ghante ke liye allow", false) { Store.guestEnabled = true; Store.guestUntil = System.currentTimeMillis() + 3600_000L; refresh() })
        cg.addView(btn("Sirf 4 ghante ke liye allow", false) { Store.guestEnabled = true; Store.guestUntil = System.currentTimeMillis() + 4 * 3600_000L; refresh() })
        cg.addView(btn("Guest folder badlo", false) { askGuestFolder() })
        guestUpBtn = btn("", false) { Store.guestUpload = !Store.guestUpload; refresh() }
        cg.addView(guestUpBtn)
        guestDelBtn = btn("", false) { Store.guestDelete = !Store.guestDelete; refresh() }
        cg.addView(guestDelBtn)
        cg.addView(btn("Guest password set / hatao", false) { askGuestPassword() })
        root.addView(cg)

        // storage card
        val c4 = box()
        c4.addView(tv("Storage", 16f, text, true))
        storageBtn = btn("", false) { toggleStorage() }
        c4.addView(storageBtn)
        root.addView(c4)

        // reliability card
        val c5 = box()
        c5.addView(tv("Background me chalane ke liye", 16f, text, true))
        c5.addView(
            tv(
                "Battery optimization band karo, warna Android server ko band kar sakta hai. " +
                    "Phone ko charging par rakhna behtar hai.", 13f, muted
            )
        )
        c5.addView(btn("Battery optimization band karo", false) { askBattery() })
        c5.addView(btn("Remote access: Tailscale guide", false) {
            toast("Tailscale app install karo, phone aur doosre device dono me login karo. Phir Tailscale wala address (100.x.x.x) use karo.")
        })
        root.addView(c5)

        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        sv.addView(root)
        setContentView(sv)
    }

    private fun refresh() {
        val running = QServer.running
        guestOnBtn.text = if (Store.guestEnabled) "Guest access ON (band karne ke liye dabao)" else "Guest access BAND (chalu karne ke liye dabao)"
        guestUpBtn.text = if (Store.guestUpload) "Guest upload: ALLOWED (dabao to band)" else "Guest upload: BAND (dabao to allow)"
        guestDelBtn.text = if (Store.guestDelete) "Guest delete/rename: ALLOWED (dabao to band)" else "Guest delete/rename: BAND (dabao to allow)"
        val until = Store.guestUntil
        guestInfo.text = "Folder: " + Store.guestFolder + "\n" + when {
            !Store.guestEnabled -> "Abhi guest access band hai"
            until == 0L -> "Allowed: jab tak aap band na karo"
            System.currentTimeMillis() >= until -> "Time khatam, guest access band"
            else -> "Allowed: " + java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(until)) + " tak"
        } + "\nGuest password: " + (if (Store.hasGuestPassword) "set hai" else "nahi hai (code se pair karo)")
        status.text = if (running) "Server chal raha hai" else "Server band hai"
        status.setTextColor(if (running) Color.parseColor("#3DDC97") else Color.parseColor("#FF6B6B"))
        toggle.text = if (running) "Stop Server" else "Start Server"
        pwBtn.text = if (Store.hasPassword) "Password badlo" else "Password set karo (zaroori)"

        val sb = StringBuilder()
        if (running) {
            val addrs = Net.addresses()
            if (addrs.isEmpty()) sb.append("Koi network nahi mila. Wi-Fi ya hotspot on karo.")
            for (a in addrs) {
                val label = when (a.kind) {
                    "wifi" -> "Wi-Fi"
                    "hotspot" -> "Hotspot"
                    "tailscale" -> "Tailscale (remote)"
                    "other" -> "Network"
                    else -> a.kind
                }
                sb.append(label).append(": http://").append(a.ip).append(':').append(Store.port).append('\n')
            }
        } else {
            QServer.lastError?.let { sb.append(it) }
        }
        urls.text = sb.toString().trim()
        if (pairView.text.toString().all { it == '-' || it.isDigit() }) {
            val c = Pairing.current()
            pairView.text = c ?: "------"
        }
        storageBtn.text = if (Store.usingPublic())
            "Poora phone storage use ho raha hai (badalne ke liye dabao)"
        else "App folder use ho raha hai (poora phone storage kholne ke liye dabao)"
    }

    private fun onToggle() {
        if (QServer.running) {
            ServerService.stop(this)
            ui.postDelayed({ refresh() }, 500)
            return
        }
        if (!Store.hasPassword) {
            toast("Pehle password set karo")
            askPassword()
            return
        }
        ServerService.start(this)
        ui.postDelayed({ refresh() }, 800)
    }

    private fun copyUrl() {
        val u = Net.primaryUrl(Store.port)
        if (u == null) {
            toast("Network nahi mila")
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", u))
        toast("Copy ho gaya: $u")
    }

    private fun askPassword() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val old = EditText(this).apply {
            hint = "Purana password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val p1 = EditText(this).apply {
            hint = "Naya password (6+ character)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val p2 = EditText(this).apply {
            hint = "Dobara likho"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        if (Store.hasPassword) box.addView(old)
        box.addView(p1)
        box.addView(p2)
        android.app.AlertDialog.Builder(this)
            .setTitle("Password")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val a = p1.text.toString()
                when {
                    Store.hasPassword && !Store.checkPassword(old.text.toString()) -> toast("Purana password galat hai")
                    a.length < 6 -> toast("Password kam se kam 6 character ka ho")
                    a != p2.text.toString() -> toast("Dono password alag hain")
                    else -> {
                        Store.setPassword(a)
                        toast("Password save ho gaya")
                        refresh()
                    }
                }
            }
            .show()
    }

    private fun askGuestFolder() {
        val et = EditText(this).apply { setText(Store.guestFolder); hint = "Folder ka naam, jaise Guest ya Movies/Share" }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(et) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Guest folder")
            .setMessage("Sirf isi folder me guest kaam karega. Folder na ho to ban jaayega.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val gf = et.text.toString().trim().trim('/')
                val d = FileOps.resolve(gf)
                if (gf.isEmpty() || d == null || d.path == FileOps.root().path) {
                    toast("Folder sahi nahi hai")
                } else {
                    d.mkdirs()
                    Store.guestFolder = FileOps.rel(FileOps.root(), d)
                    toast("Guest folder: " + Store.guestFolder)
                    refresh()
                }
            }.show()
    }

    private fun askGuestPassword() {
        val et = EditText(this).apply { hint = "Guest password (4+), khali = hatao" }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(et) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Guest password")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val p = et.text.toString()
                if (p.isNotEmpty() && p.length < 4) toast("Kam se kam 4 character")
                else { Store.setGuestPassword(p); toast("Save ho gaya"); refresh() }
            }.show()
    }

    private fun toggleStorage() {
        if (Store.publicStorage) {
            Store.publicStorage = false
            toast("App folder use hoga")
            refresh()
            return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                toast("'Sabhi files ka access' allow karo, phir wapas aao")
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
                Store.publicStorage = true
                return
            }
        } else if (!Store.hasAllFiles()) {
            requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 2
            )
        }
        Store.publicStorage = true
        toast("Poora phone storage use hoga (QunverioTurbo folder me)")
        refresh()
    }

    private fun askBattery() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Pehle se band hai")
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
