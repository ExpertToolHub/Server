package com.qunverio.cloud

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import io.ktor.http.ContentType
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.content.OutgoingContent
import io.ktor.server.application.Application
import io.ktor.server.application.ApplicationCall
import io.ktor.server.application.call
import io.ktor.server.application.install
import io.ktor.server.plugins.statuspages.StatusPages
import io.ktor.server.request.header
import io.ktor.server.request.httpMethod
import io.ktor.server.request.receiveChannel
import io.ktor.server.request.receiveText
import io.ktor.server.response.header
import io.ktor.server.response.respond
import io.ktor.server.response.respondBytes
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.put
import io.ktor.server.routing.routing
import io.ktor.utils.io.ByteWriteChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

private const val COOKIE = "qc_session"
private const val MAX_CHUNK = 32L * 1024 * 1024

/** 6-digit one-time code shown in the app so a new device can pair without typing the password. */
object Pairing {
    @Volatile private var code: String? = null
    @Volatile private var expires = 0L
    private val rnd = java.security.SecureRandom()

    fun newCode(): String {
        val c = "%06d".format(rnd.nextInt(1_000_000))
        code = c
        expires = System.currentTimeMillis() + 5 * 60_000
        return c
    }

    fun current(): String? =
        if (code != null && System.currentTimeMillis() < expires) code else null

    fun consume(input: String): Boolean {
        val c = current() ?: return false
        if (!java.security.MessageDigest.isEqual(c.toByteArray(), input.toByteArray())) return false
        code = null
        return true
    }
}

private class Fail(var count: Int, var until: Long)

private val fails = ConcurrentHashMap<String, Fail>()

private fun lockedFor(ip: String): Long {
    val f = fails[ip] ?: return 0
    val left = f.until - System.currentTimeMillis()
    return if (left > 0) left else 0
}

private fun recordFail(ip: String) {
    val f = fails.getOrPut(ip) { Fail(0, 0) }
    f.count++
    if (f.count >= 5) {
        f.until = System.currentTimeMillis() + 60_000L * minOf(f.count - 4, 30)
    }
}

private fun ApplicationCall.ip(): String = request.local.remoteHost

private suspend fun ApplicationCall.json(o: Any, status: HttpStatusCode = HttpStatusCode.OK) {
    response.header(HttpHeaders.CacheControl, "no-store")
    respondText(o.toString(), ContentType.Application.Json, status)
}

private suspend fun ApplicationCall.err(status: HttpStatusCode, msg: String) {
    json(JSONObject().put("error", msg), status)
}

/** Checks the session cookie. Replies with an error and returns null when not allowed. */
private suspend fun ApplicationCall.auth(admin: Boolean = false, write: Boolean = false, manage: Boolean = false): Store.Device? {
    val token = request.cookies[COOKIE]
    val d = if (token.isNullOrEmpty()) null else Store.sessionFor(token, ip())
    if (d == null) {
        err(HttpStatusCode.Unauthorized, "Login karo")
        return null
    }
    // CSRF protection: every state-changing request must carry our custom header.
    val m = request.httpMethod.value
    if (m != "GET" && m != "HEAD" && request.header("X-QC") != "1") {
        err(HttpStatusCode.Forbidden, "Bad request")
        return null
    }
    if (admin && !d.admin) {
        err(HttpStatusCode.Forbidden, "Sirf admin ye kar sakta hai")
        return null
    }
    if (!d.admin && !Store.guestActive()) {
        err(HttpStatusCode.Forbidden, "Guest access abhi band hai (admin ne band kiya hai)")
        return null
    }
    if (write && !Store.canUpload(d)) {
        err(HttpStatusCode.Forbidden, "Upload ki permission nahi hai")
        return null
    }
    if (manage && !Store.canManage(d)) {
        err(HttpStatusCode.Forbidden, "Delete / rename ki permission admin ne band rakhi hai")
        return null
    }
    return d
}

private suspend fun ApplicationCall.body(): JSONObject = try {
    val t = receiveText()
    if (t.length > 20_000) JSONObject() else JSONObject(t)
} catch (e: Exception) {
    JSONObject()
}

private fun cookieHeader(token: String) =
    "$COOKIE=$token; Path=/; HttpOnly; SameSite=Strict; Max-Age=${30 * 24 * 3600}"

private fun readAsset(name: String): ByteArray? = try {
    QServer.ctx.assets.open("web/$name").use { it.readBytes() }
} catch (e: Exception) {
    null
}

private fun fsMsg(e: Exception) = if (e is FsError) e.message ?: "Error" else "Kuch galat ho gaya"

fun Application.qcModule() {
    install(StatusPages) {
        exception<Throwable> { call, cause ->
            try {
                call.err(HttpStatusCode.InternalServerError, "Server error: ${cause.javaClass.simpleName}")
            } catch (e: Exception) {
                // response already started
            }
        }
    }

    routing {
        // ---------- dashboard files (public: only the login/UI shell, no user data) ----------
        for ((path, file, type) in listOf(
            Triple("/", "index.html", ContentType.Text.Html),
            Triple("/app.css", "app.css", ContentType.Text.CSS),
            Triple("/app.js", "app.js", ContentType.Application.JavaScript)
        )) {
            get(path) {
                val b = readAsset(file)
                if (b == null) {
                    call.respondText("Not found", status = HttpStatusCode.NotFound)
                } else {
                    call.response.header(HttpHeaders.CacheControl, "no-cache")
                    call.response.header("X-Content-Type-Options", "nosniff")
                    call.response.header("X-Frame-Options", "DENY")
                    call.respondBytes(b, type)
                }
            }
        }

        // ---------- login / pairing ----------
        post("/api/login") {
            val ip = call.ip()
            val wait = lockedFor(ip)
            if (wait > 0) {
                call.err(HttpStatusCode.TooManyRequests, "Bahut galat try. ${wait / 1000 + 1} second baad try karo")
                return@post
            }
            if (call.request.header("X-QC") != "1") {
                call.err(HttpStatusCode.Forbidden, "Bad request")
                return@post
            }
            val b = call.body()
            val pw = b.optString("password")
            val name = b.optString("name").ifBlank { "Device" }.take(40)
            if (b.optBoolean("guest")) {
                if (!Store.guestActive()) {
                    call.err(HttpStatusCode.Forbidden, "Guest access abhi band hai")
                    return@post
                }
                if (!Store.hasGuestPassword || !Store.checkGuestPassword(pw)) {
                    recordFail(ip)
                    call.err(HttpStatusCode.Unauthorized, "Guest password galat hai")
                    return@post
                }
                fails.remove(ip)
                val (gt, gd) = Store.createSession(name, ip, call.request.header(HttpHeaders.UserAgent) ?: "", false, canWrite = true)
                Activity.log(gd.name, "guest login", ip)
                call.response.header(HttpHeaders.SetCookie, cookieHeader(gt))
                call.json(JSONObject().put("ok", true))
                return@post
            }
            if (!Store.hasPassword) {
                call.err(HttpStatusCode.PreconditionFailed, "Pehle phone ke app me password set karo")
                return@post
            }
            if (!Store.checkPassword(pw)) {
                recordFail(ip)
                call.err(HttpStatusCode.Unauthorized, "Password galat hai")
                return@post
            }
            fails.remove(ip)
            val (token, d) = Store.createSession(name, ip, call.request.header(HttpHeaders.UserAgent) ?: "", true)
            Activity.log(d.name, "login", ip)
            call.response.header(HttpHeaders.SetCookie, cookieHeader(token))
            call.json(JSONObject().put("ok", true))
        }

        post("/api/pair") {
            val ip = call.ip()
            val wait = lockedFor(ip)
            if (wait > 0) {
                call.err(HttpStatusCode.TooManyRequests, "Bahut galat try. ${wait / 1000 + 1} second baad try karo")
                return@post
            }
            if (call.request.header("X-QC") != "1") {
                call.err(HttpStatusCode.Forbidden, "Bad request")
                return@post
            }
            val b = call.body()
            val name = b.optString("name").ifBlank { "Device" }.take(40)
            if (!Pairing.consume(b.optString("code"))) {
                recordFail(ip)
                call.err(HttpStatusCode.Unauthorized, "Code galat ya expire ho gaya")
                return@post
            }
            fails.remove(ip)
            val (token, d) = Store.createSession(name, ip, call.request.header(HttpHeaders.UserAgent) ?: "", false, canWrite = true)
            Activity.log(d.name, "paired", ip)
            call.response.header(HttpHeaders.SetCookie, cookieHeader(token))
            call.json(JSONObject().put("ok", true))
        }

        post("/api/logout") {
            val d = call.auth() ?: return@post
            call.request.cookies[COOKIE]?.let { Store.logout(it) }
            Activity.log(d.name, "logout", "")
            call.response.header(HttpHeaders.SetCookie, "$COOKIE=; Path=/; Max-Age=0")
            call.json(JSONObject().put("ok", true))
        }

        get("/api/me") {
            val token = call.request.cookies[COOKIE]
            val d = if (token.isNullOrEmpty()) null else Store.sessionFor(token, call.ip())
            if (d == null) {
                call.json(
                    JSONObject().put("auth", false).put("hasPassword", Store.hasPassword)
                        .put("hasGuestPassword", Store.hasGuestPassword)
                        .put("guestActive", Store.guestActive())
                        .put("name", Store.serverName), HttpStatusCode.OK
                )
            } else {
                val dj = d.toJson()
                    .put("canWrite", Store.canUpload(d) && (d.admin || Store.guestActive()))
                    .put("canManage", Store.canManage(d))
                    .put("guestActive", d.admin || Store.guestActive())
                call.json(JSONObject().put("auth", true).put("device", dj).put("name", Store.serverName))
            }
        }

        // ---------- dashboard status ----------
        get("/api/status") {
            val d = call.auth() ?: return@get
            FileOps.refreshIfStale(5000)
            val ctx = QServer.ctx
            val root = FileOps.root()
            val st = StatFs(root.path)
            val mi = ActivityManager.MemoryInfo()
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val rt = Runtime.getRuntime()
            val addrs = JSONArray()
            for (a in Net.addresses()) {
                addrs.put(
                    JSONObject().put("iface", a.iface).put("kind", a.kind)
                        .put("url", "http://${a.ip}:${Store.port}")
                )
            }
            val devs = Store.deviceList()
            val now = System.currentTimeMillis()
            val o = JSONObject()
                .put("name", Store.serverName)
                .put("running", true)
                .put("uptime", now - Stats.startedAt)
                .put("addresses", addrs)
                .put("remoteUrl", Store.remoteUrl)
                .put("totalSpace", st.totalBytes)
                .put("freeSpace", st.availableBytes)
                .put("usedByCloud", FileOps.used)
                .put("ramTotal", mi.totalMem)
                .put("ramFree", mi.availMem)
                .put("appRam", rt.totalMemory() - rt.freeMemory())
                .put("cpu", Stats.cpu)
                .put("speedIn", Stats.speedIn)
                .put("speedOut", Stats.speedOut)
                .put("bytesIn", Stats.bytesIn.get())
                .put("bytesOut", Stats.bytesOut.get())
                .put("devicesTotal", devs.size)
                .put("devicesOnline", devs.count { now - it.lastSeen < 60_000 })
                .put("transfers", Transfers.json())
                .put("activity", Activity.recent(30))
                .put("storageMode", if (Store.usingPublic()) "public" else "app")
                .put("root", root.path)
                .put("admin", d.admin)
                .put("fastPort", Fast.port)
            if (d.admin) {
                o.put(
                    "guest", JSONObject().put("enabled", Store.guestEnabled).put("folder", Store.guestFolder)
                        .put("upload", Store.guestUpload).put("delete", Store.guestDelete)
                        .put("until", Store.guestUntil).put("active", Store.guestActive())
                        .put("hasPassword", Store.hasGuestPassword)
                )
            } else {
                o.put("addresses", JSONArray()).put("transfers", JSONArray()).put("activity", JSONArray())
                    .put("remoteUrl", "").put("root", "").put("devicesTotal", 0).put("devicesOnline", 0)
                val gb = FileOps.baseOf(d)
                o.put("usedByCloud", gb.walkTopDown().filter { it.isFile }.sumOf { it.length() })
            }
            call.json(o)
        }

        // ---------- file manager ----------
        get("/api/list") {
            val d = call.auth() ?: return@get
            val base = FileOps.baseOf(d)
            val dir = FileOps.resolve(call.request.queryParameters["path"], base)
            if (dir == null || !dir.isDirectory) {
                call.err(HttpStatusCode.NotFound, "Folder nahi mila")
                return@get
            }
            call.json(
                JSONObject().put("path", FileOps.rel(base, dir)).put("items", FileOps.list(dir, base))
            )
        }

        get("/api/search") {
            val d = call.auth() ?: return@get
            val q = (call.request.queryParameters["q"] ?: "").take(100)
            val sb = FileOps.baseOf(d)
            val r = withContext(Dispatchers.IO) { FileOps.search(q, sb) }
            call.json(JSONObject().put("items", r))
        }

        post("/api/mkdir") {
            val d = call.auth(write = true) ?: return@post
            val b = call.body()
            val parent = FileOps.resolve(b.optString("path"), FileOps.baseOf(d))
            if (parent == null || !parent.isDirectory) {
                call.err(HttpStatusCode.NotFound, "Folder nahi mila")
                return@post
            }
            try {
                val f = FileOps.mkdir(parent, b.optString("name"))
                Activity.log(d.name, "folder", f.name)
                call.json(JSONObject().put("ok", true))
            } catch (e: Exception) {
                call.err(HttpStatusCode.BadRequest, fsMsg(e))
            }
        }

        post("/api/rename") {
            val d = call.auth(manage = true) ?: return@post
            val b = call.body()
            val base = FileOps.baseOf(d)
            val f = FileOps.resolve(b.optString("path"), base)
            if (f == null || !f.exists()) {
                call.err(HttpStatusCode.NotFound, "Item nahi mila")
                return@post
            }
            try {
                val old = f.name
                val t = FileOps.rename(f, b.optString("name"), base)
                Activity.log(d.name, "rename", "$old -> ${t.name}")
                call.json(JSONObject().put("ok", true))
            } catch (e: Exception) {
                call.err(HttpStatusCode.BadRequest, fsMsg(e))
            }
        }

        post("/api/move") {
            val d = call.auth(manage = true) ?: return@post
            val b = call.body()
            val base = FileOps.baseOf(d)
            val f = FileOps.resolve(b.optString("path"), base)
            val to = FileOps.resolve(b.optString("to"), base)
            if (f == null || !f.exists() || to == null) {
                call.err(HttpStatusCode.NotFound, "Item nahi mila")
                return@post
            }
            try {
                val t = withContext(Dispatchers.IO) { FileOps.move(f, to, base) }
                Activity.log(d.name, "move", t.name)
                call.json(JSONObject().put("ok", true))
            } catch (e: Exception) {
                call.err(HttpStatusCode.BadRequest, fsMsg(e))
            }
        }

        post("/api/delete") {
            val d = call.auth(manage = true) ?: return@post
            val b = call.body()
            val base = FileOps.baseOf(d)
            val f = FileOps.resolve(b.optString("path"), base)
            if (f == null || !f.exists()) {
                call.err(HttpStatusCode.NotFound, "Item nahi mila")
                return@post
            }
            try {
                val n = f.name
                withContext(Dispatchers.IO) { FileOps.delete(f, base) }
                Activity.log(d.name, "delete", n)
                call.json(JSONObject().put("ok", true))
            } catch (e: Exception) {
                call.err(HttpStatusCode.BadRequest, fsMsg(e))
            }
        }

        // ---------- download + streaming (HTTP Range) ----------
        get("/api/file") {
            val d = call.auth() ?: return@get
            val f = FileOps.resolve(call.request.queryParameters["path"], FileOps.baseOf(d))
            if (f == null || !f.isFile) {
                call.err(HttpStatusCode.NotFound, "File nahi mili")
                return@get
            }
            val forceDl = call.request.queryParameters["dl"] == "1"
            serveFile(call, f, d, forceDl)
        }

        // ---------- resumable chunked upload ----------
        get("/api/upload/status") {
            val d = call.auth(write = true) ?: return@get
            val q = call.request.queryParameters
            val name = FileOps.cleanName(q["name"] ?: "")
            val total = q["total"]?.toLongOrNull()
            if (name == null || total == null || total < 0) {
                call.err(HttpStatusCode.BadRequest, "Bad request")
                return@get
            }
            val id = FileOps.uploadId(d.id, q["dir"] ?: "", name, total)
            val tmp = File(File(FileOps.root(), FileOps.TMP), "$id.part")
            call.json(JSONObject().put("offset", if (tmp.isFile) tmp.length() else 0L))
        }

        put("/api/upload") {
            val d = call.auth(write = true) ?: return@put
            val q = call.request.queryParameters
            val dirRel = q["dir"] ?: ""
            val dir = FileOps.resolve(dirRel, FileOps.baseOf(d))
            val name = FileOps.cleanName(q["name"] ?: "")
            val total = q["total"]?.toLongOrNull()
            val offset = q["offset"]?.toLongOrNull()
            if (dir == null || !dir.isDirectory || name == null || total == null || offset == null ||
                total < 0 || offset < 0 || offset > total
            ) {
                call.err(HttpStatusCode.BadRequest, "Upload request sahi nahi hai")
                return@put
            }
            val declared = call.request.header(HttpHeaders.ContentLength)?.toLongOrNull() ?: -1L
            if (declared < 0 || declared > MAX_CHUNK || offset + declared > total) {
                call.err(HttpStatusCode.BadRequest, "Chunk size sahi nahi hai")
                return@put
            }
            val root = FileOps.root()
            if (root.usableSpace < declared + 100L * 1024 * 1024) {
                call.err(HttpStatusCode.InsufficientStorage, "Phone me jagah kam hai")
                return@put
            }
            if (Gate.active.incrementAndGet() > Gate.MAX) {
                Gate.active.decrementAndGet()
                call.err(HttpStatusCode.ServiceUnavailable, "Server busy hai, thodi der baad try karo")
                return@put
            }
            val id = FileOps.uploadId(d.id, dirRel, name, total)
            try {
                val tmpDir = File(root, FileOps.TMP)
                tmpDir.mkdirs()
                val tmp = File(tmpDir, "$id.part")
                val have = if (tmp.isFile) tmp.length() else 0L
                if (offset != have) {
                    // client is out of sync: tell it where to continue from
                    call.json(
                        JSONObject().put("error", "offset").put("offset", have),
                        HttpStatusCode.Conflict
                    )
                    return@put
                }
                val tr = Transfers.map.getOrPut(id) { Transfer(id, name, "up", total, d.name) }
                tr.done.set(offset)
                tr.touched = System.currentTimeMillis()

                val ch = call.receiveChannel()
                val buf = ByteArray(512 * 1024)
                var got = 0L
                RandomAccessFile(tmp, "rw").use { raf ->
                    raf.seek(offset)
                    while (got < declared) {
                        val want = minOf(buf.size.toLong(), declared - got).toInt()
                        try {
                            ch.readFully(buf, 0, want)
                        } catch (e: Exception) {
                            break
                        }
                        withContext(Dispatchers.IO) { raf.write(buf, 0, want) }
                        got += want
                        Stats.bytesIn.addAndGet(want.toLong())
                        tr.done.addAndGet(want.toLong())
                        tr.touched = System.currentTimeMillis()
                    }
                }
                if (got != declared) {
                    call.err(HttpStatusCode.BadRequest, "Chunk poora nahi aaya")
                    return@put
                }
                val newSize = offset + got
                if (newSize == total) {
                    val finalFile = withContext(Dispatchers.IO) {
                        val t = FileOps.unique(dir, name)
                        if (!tmp.renameTo(t)) {
                            tmp.copyTo(t, false)
                            tmp.delete()
                        }
                        t
                    }
                    Transfers.map.remove(id)
                    Activity.log(d.name, "upload", finalFile.name)
                    call.json(
                        JSONObject().put("done", true).put("offset", newSize).put("name", finalFile.name)
                    )
                } else {
                    call.json(JSONObject().put("done", false).put("offset", newSize))
                }
            } finally {
                Gate.active.decrementAndGet()
            }
        }

        post("/api/upload/cancel") {
            val d = call.auth(write = true) ?: return@post
            val b = call.body()
            val name = FileOps.cleanName(b.optString("name")) ?: run {
                call.err(HttpStatusCode.BadRequest, "Bad request")
                return@post
            }
            val id = FileOps.uploadId(d.id, b.optString("dir"), name, b.optLong("total", -1))
            File(File(FileOps.root(), FileOps.TMP), "$id.part").delete()
            Transfers.map.remove(id)
            call.json(JSONObject().put("ok", true))
        }

        // ---------- fast mode tickets + speed test ----------
        get("/api/ticket") {
            val d = call.auth() ?: return@get
            val fs = Fast.server
            if (fs == null) {
                call.err(HttpStatusCode.ServiceUnavailable, "Fast mode band hai")
                return@get
            }
            val q = call.request.queryParameters
            val write = q["write"] == "1"
            if (write && !Store.canUpload(d)) {
                call.err(HttpStatusCode.Forbidden, "Upload ki permission nahi hai")
                return@get
            }
            val rel = q["path"] ?: ""
            if (rel.isNotEmpty()) {
                val f = FileOps.resolve(rel, FileOps.baseOf(d))
                if (f == null || !f.isFile) {
                    call.err(HttpStatusCode.NotFound, "File nahi mili")
                    return@get
                }
            }
            val tok = fs.issue(rel, d.id, d.name, write, null, 12L * 3600_000L)
            call.json(JSONObject().put("port", Fast.port).put("token", tok))
        }

        // network-only speed test through the normal server (to compare with the fast one)
        get("/api/zero") {
            call.auth() ?: return@get
            val mb = (call.request.queryParameters["mb"]?.toLongOrNull() ?: 100L).coerceIn(1L, 1000L)
            val total = mb * 1024 * 1024
            call.response.header(HttpHeaders.CacheControl, "no-store")
            call.respond(object : OutgoingContent.WriteChannelContent() {
                override val contentType: ContentType = ContentType.Application.OctetStream
                override val contentLength: Long = total

                override suspend fun writeTo(channel: ByteWriteChannel) {
                    val buf = ByteArray(256 * 1024)
                    var left = total
                    while (left > 0) {
                        val n = minOf(buf.size.toLong(), left).toInt()
                        channel.writeFully(buf, 0, n)
                        left -= n
                    }
                }
            })
        }

        // ---------- share links ----------
        post("/api/share") {
            val d = call.auth(admin = true) ?: return@post
            val b = call.body()
            val f = FileOps.resolve(b.optString("path"))
            if (f == null || !f.exists() || f.path == FileOps.root().path) {
                call.err(HttpStatusCode.NotFound, "Item nahi mila")
                return@post
            }
            val hours = b.optInt("hours", 24).coerceIn(1, 24 * 30)
            val s = Shares.create(FileOps.rel(FileOps.root(), f), f.name, f.isDirectory, hours, d.name)
            Activity.log(d.name, "share", f.name)
            call.json(JSONObject().put("token", s.token).put("url", shareUrl(s)).put("expires", s.expires))
        }

        get("/api/shares") {
            call.auth(admin = true) ?: return@get
            val a = JSONArray()
            for (s in Shares.list()) {
                a.put(
                    JSONObject().put("token", s.token).put("name", s.name).put("dir", s.dir)
                        .put("created", s.created).put("expires", s.expires).put("by", s.by)
                        .put("url", shareUrl(s))
                )
            }
            call.json(JSONObject().put("shares", a))
        }

        post("/api/share/revoke") {
            val d = call.auth(admin = true) ?: return@post
            Shares.revoke(call.body().optString("token"))
            Activity.log(d.name, "share revoked", "")
            call.json(JSONObject().put("ok", true))
        }

        // public (no login): the random token in the link is the permission
        get("/s/{token}") { handleShare(call) }
        get("/s/{token}/{rest...}") { handleShare(call) }

        // ---------- devices (admin only) ----------
        get("/api/devices") {
            val d = call.auth(admin = true) ?: return@get
            val a = JSONArray()
            for (x in Store.deviceList()) a.put(x.toJson().put("self", x.id == d.id))
            call.json(JSONObject().put("devices", a))
        }

        post("/api/device/remove") {
            val d = call.auth(admin = true) ?: return@post
            val id = call.body().optString("id")
            if (id == d.id) {
                call.err(HttpStatusCode.BadRequest, "Apne aap ko yahan se remove nahi kar sakte, Logout use karo")
                return@post
            }
            Store.removeDevice(id)
            Activity.log(d.name, "device removed", id)
            call.json(JSONObject().put("ok", true))
        }

        post("/api/device/write") {
            val d = call.auth(admin = true) ?: return@post
            val b = call.body()
            Store.setWrite(b.optString("id"), b.optBoolean("value", true))
            Activity.log(d.name, "permission", b.optString("id"))
            call.json(JSONObject().put("ok", true))
        }

        post("/api/device/revoke-others") {
            val d = call.auth(admin = true) ?: return@post
            Store.revokeAllExcept(d.id)
            Activity.log(d.name, "revoke others", "")
            call.json(JSONObject().put("ok", true))
        }

        post("/api/settings") {
            val d = call.auth(admin = true) ?: return@post
            val b = call.body()
            if (b.has("name")) Store.serverName = b.optString("name").ifBlank { "Qunverio Turbo" }.take(40)
            if (b.has("remoteUrl")) {
                val u = b.optString("remoteUrl").trim().take(200)
                Store.remoteUrl = if (u.startsWith("http://") || u.startsWith("https://") || u.isEmpty()) u else ""
            }
            if (b.has("guestEnabled")) Store.guestEnabled = b.optBoolean("guestEnabled")
            if (b.has("guestUpload")) Store.guestUpload = b.optBoolean("guestUpload")
            if (b.has("guestDelete")) Store.guestDelete = b.optBoolean("guestDelete")
            if (b.has("guestHours")) {
                val h = b.optInt("guestHours", 0)
                Store.guestUntil = if (h <= 0) 0L else System.currentTimeMillis() + h * 3600_000L
            }
            if (b.has("guestPassword")) {
                val gp = b.optString("guestPassword")
                if (gp.isNotEmpty() && gp.length < 4) {
                    call.err(HttpStatusCode.BadRequest, "Guest password kam se kam 4 character ka ho")
                    return@post
                }
                Store.setGuestPassword(gp)
            }
            if (b.has("guestFolder")) {
                val gf = b.optString("guestFolder").trim().trim('/')
                val gdir = FileOps.resolve(gf)
                if (gf.isEmpty() || gdir == null || gdir.path == FileOps.root().path) {
                    call.err(HttpStatusCode.BadRequest, "Guest folder sahi nahi hai")
                    return@post
                }
                gdir.mkdirs()
                if (!gdir.isDirectory) {
                    call.err(HttpStatusCode.BadRequest, "Folder nahi ban paya")
                    return@post
                }
                Store.guestFolder = FileOps.rel(FileOps.root(), gdir)
            }
            Activity.log(d.name, "settings", "")
            call.json(JSONObject().put("ok", true))
        }

        post("/api/password") {
            val d = call.auth(admin = true) ?: return@post
            val b = call.body()
            if (!Store.checkPassword(b.optString("old"))) {
                call.err(HttpStatusCode.Unauthorized, "Purana password galat hai")
                return@post
            }
            val n = b.optString("new")
            if (n.length < 6) {
                call.err(HttpStatusCode.BadRequest, "Naya password kam se kam 6 character ka ho")
                return@post
            }
            Store.setPassword(n)
            Store.revokeAllExcept(d.id)
            Activity.log(d.name, "password changed", "")
            call.json(JSONObject().put("ok", true))
        }
    }
}

private fun encSeg(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

private fun shareUrl(s: Shares.Share): String =
    "/s/" + s.token + "/" + (if (s.dir) "" else encSeg(s.name))

private fun htmlEsc(s: String): String =
    s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")

/** Sends a shared file through the fast server (redirect with a short-lived ticket), or directly as fallback. */
private suspend fun shareFile(call: ApplicationCall, s: Shares.Share, f: File, d: Store.Device, forceDl: Boolean) {
    val fs = Fast.server
    val host = (call.request.header(HttpHeaders.Host) ?: "").substringBefore(':')
    val ttl = minOf(6 * 3600_000L, s.expires - System.currentTimeMillis())
    if (fs == null || host.isEmpty() || ttl <= 0) {
        serveFile(call, f, d, forceDl)
        return
    }
    val tok = fs.issue(FileOps.rel(FileOps.root(), f), "share", "Share link", false, s.token, ttl)
    val url = "http://" + host + ":" + Fast.port + "/f/" + tok + "/" + encSeg(f.name) + (if (forceDl) "?dl=1" else "")
    call.response.header(HttpHeaders.Location, url)
    call.respondText("", status = HttpStatusCode.Found)
}

/** Serves a shared file, or a simple HTML listing for a shared folder. */
private suspend fun handleShare(call: ApplicationCall) {
    val s = Shares.get(call.parameters["token"] ?: "")
    val base = if (s == null) null else FileOps.resolve(s.path)
    if (s == null || base == null || !base.exists()) {
        call.respondText("Link expire ho gaya ya galat hai", status = HttpStatusCode.NotFound)
        return
    }
    val d = Store.Device("share", "Share link", 0L, 0L, call.ip(), false, false, "")
    val forceDl = call.request.queryParameters["dl"] == "1"
    if (!s.dir) {
        if (!base.isFile) {
            call.respondText("File nahi mili", status = HttpStatusCode.NotFound)
            return
        }
        shareFile(call, s, base, d, forceDl)
        return
    }
    val sub = (call.parameters.getAll("rest") ?: emptyList()).filter { it.isNotEmpty() }.joinToString("/")
    val target = FileOps.resolve(if (sub.isEmpty()) s.path else s.path + "/" + sub)
    if (target == null || !target.exists() ||
        !(target.path == base.path || target.path.startsWith(base.path + File.separator))
    ) {
        call.respondText("Nahi mila", status = HttpStatusCode.NotFound)
        return
    }
    if (target.isFile) {
        shareFile(call, s, target, d, forceDl)
        return
    }
    val items = FileOps.list(target)
    val sb = StringBuilder()
    sb.append("<!doctype html><html><head><meta charset=\"utf-8\">")
    sb.append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">")
    sb.append("<title>").append(htmlEsc(s.name)).append("</title>")
    sb.append("<style>body{font:16px system-ui,sans-serif;max-width:720px;margin:0 auto;padding:16px}")
    sb.append("a{display:block;padding:12px 8px;border-bottom:1px solid #ddd;color:#2a5bd7;text-decoration:none;word-break:break-all}")
    sb.append("small{color:#777}</style></head><body>")
    sb.append("<h2>").append(htmlEsc(if (sub.isEmpty()) s.name else sub)).append("</h2>")
    if (sub.isNotEmpty()) {
        val parent = if (sub.contains('/')) sub.substringBeforeLast('/') else ""
        val href = "/s/" + s.token + "/" + parent.split('/').filter { it.isNotEmpty() }.joinToString("/") { encSeg(it) }
        sb.append("<a href=\"").append(href).append(if (parent.isEmpty()) "" else "/").append("\">&larr; ..</a>")
    }
    for (i in 0 until items.length()) {
        val o = items.getJSONObject(i)
        val nm = o.getString("name")
        val rel = if (sub.isEmpty()) nm else "$sub/$nm"
        val href = "/s/" + s.token + "/" + rel.split('/').joinToString("/") { encSeg(it) } + (if (o.getBoolean("dir")) "/" else "")
        sb.append("<a href=\"").append(href).append("\">")
        sb.append(if (o.getBoolean("dir")) "&#128193; " else "&#128196; ").append(htmlEsc(nm))
        if (!o.getBoolean("dir")) sb.append(" <small>").append(o.getLong("size") / 1024).append(" KB</small>")
        sb.append("</a>")
    }
    if (items.length() == 0) sb.append("<p>Folder khaali hai</p>")
    sb.append("</body></html>")
    call.response.header("X-Content-Type-Options", "nosniff")
    call.response.header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'")
    call.respondText(sb.toString(), ContentType.Text.Html)
}

/** Sends a file with full HTTP Range support (single range). Never loads the whole file in RAM. */
private suspend fun serveFile(call: ApplicationCall, f: File, d: Store.Device, forceDl: Boolean) {
    val len = f.length()
    val mime = FileOps.mime(f.name)
    val inline = !forceDl && FileOps.inlineSafe(mime)

    var start = 0L
    var end = len - 1
    var partial = false
    val rh = call.request.header(HttpHeaders.Range)
    if (rh != null && rh.startsWith("bytes=") && !rh.contains(',')) {
        val spec = rh.removePrefix("bytes=").trim()
        val dash = spec.indexOf('-')
        if (dash >= 0) {
            val a = spec.substring(0, dash).trim()
            val b = spec.substring(dash + 1).trim()
            try {
                if (a.isEmpty()) {
                    val n = b.toLong()
                    if (n <= 0) throw NumberFormatException()
                    start = maxOf(0L, len - n)
                } else {
                    start = a.toLong()
                    if (b.isNotEmpty()) end = minOf(b.toLong(), len - 1)
                }
                partial = true
            } catch (e: NumberFormatException) {
                partial = false
                start = 0
                end = len - 1
            }
        }
    }
    if (partial && (start >= len || start > end)) {
        call.response.header(HttpHeaders.ContentRange, "bytes */$len")
        call.respondText("", status = HttpStatusCode.RequestedRangeNotSatisfiable)
        return
    }
    val count = if (len == 0L) 0L else end - start + 1

    if (Gate.active.incrementAndGet() > Gate.MAX) {
        Gate.active.decrementAndGet()
        call.err(HttpStatusCode.ServiceUnavailable, "Server busy hai, thodi der baad try karo")
        return
    }
    val kind = if (inline) "stream" else "down"
    val tid = "dl-" + java.util.UUID.randomUUID().toString().take(8)
    // A player makes many small range requests; only show big transfers in the list.
    val track = count > 2L * 1024 * 1024 && (start == 0L || !inline)
    val tr = Transfer(tid, f.name, kind, count, d.name)
    if (track) Transfers.map[tid] = tr
    if (start == 0L && !partial || (!inline && start == 0L)) Activity.log(d.name, if (inline) "view" else "download", f.name)

    val encName = URLEncoder.encode(f.name, "UTF-8").replace("+", "%20")
    val disp = (if (inline) "inline" else "attachment") + "; filename*=UTF-8''" + encName
    call.response.header(HttpHeaders.AcceptRanges, "bytes")
    call.response.header(HttpHeaders.ContentDisposition, disp)
    call.response.header("X-Content-Type-Options", "nosniff")
    call.response.header("Content-Security-Policy", "sandbox; default-src 'none'; media-src 'self'; img-src 'self'")
    call.response.header(HttpHeaders.CacheControl, "private, max-age=0")

    val ct = try {
        ContentType.parse(mime)
    } catch (e: Exception) {
        ContentType.Application.OctetStream
    }
    val hdrs = if (partial) Headers.build { append(HttpHeaders.ContentRange, "bytes $start-$end/$len") } else Headers.Empty

    try {
        call.respond(object : OutgoingContent.WriteChannelContent() {
            override val contentType: ContentType = ct
            override val contentLength: Long = count
            override val status: HttpStatusCode = if (partial) HttpStatusCode.PartialContent else HttpStatusCode.OK
            override val headers: Headers = hdrs

            override suspend fun writeTo(channel: ByteWriteChannel) {
                if (count == 0L) return
                RandomAccessFile(f, "r").use { raf ->
                    raf.seek(start)
                    var left = count
                    val buf = ByteArray(256 * 1024)
                    while (left > 0) {
                        val want = minOf(buf.size.toLong(), left).toInt()
                        val n = withContext(Dispatchers.IO) { raf.read(buf, 0, want) }
                        if (n <= 0) break
                        channel.writeFully(buf, 0, n)
                        left -= n
                        Stats.bytesOut.addAndGet(n.toLong())
                        tr.done.addAndGet(n.toLong())
                        tr.touched = System.currentTimeMillis()
                    }
                }
            }
        })
    } finally {
        Gate.active.decrementAndGet()
        Transfers.map.remove(tid)
    }
}
