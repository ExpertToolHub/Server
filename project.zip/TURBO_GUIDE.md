# Qunverio Turbo 2.0 — Guide (Hinglish)

## Kaise chalta hai
- Aap = ADMIN: password se login, poora control (saare folders, share links, devices, settings).
- Samne wala = GUEST: same Wi-Fi par browser me phone ka link kholta hai, "Code se pair" ya "Guest" tab (guest password) se aata hai.
  Guest ko SIRF aapka chuna hua ek folder dikhta hai. Download, upload, video/audio dekhna. Baaki phone ka koi access nahi (server side lock hai).

## Admin control (phone ke app me, "Guest access" card)
- Guest access ON/OFF
- Sirf 1 ghanta / 4 ghante ke liye allow (time khatam = guest band)
- Guest folder chuno (default: Guest)
- Guest upload allow/band
- Guest delete/rename/move allow/band (default band)
- Guest password set/hatao
(Yahi sab dashboard ke Settings me bhi hai, admin login ke baad.)

## Speed
Fast mode (port 8081) default hai. Asli speed Wi-Fi par depend karti hai: 2.4GHz ~5-10 MB/s, 5GHz ~25-50+ MB/s.
Software 100x nahi kar sakta; Wi-Fi ki limit se upar nahi ja sakta. Dono phone 5GHz Wi-Fi/hotspot par rakho.

## Install / update
1. GitHub repo me purana project.zip delete karo.
2. Naya zip ka naam EXACT `project.zip` rakho, upload + Commit.
3. Actions green hone do, Releases se Qunverio-Cloud.apk download karo.
Ye alag app hai (com.qunverio.turbo), purane Qunverio Cloud ke saath bhi chal sakta hai (port alag rakho: Cloud 8080, Turbo ke liye purana band karo ya port badlo).
